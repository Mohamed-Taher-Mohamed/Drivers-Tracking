import { Feather } from "@expo/vector-icons";
import { Redirect, useRouter } from "expo-router";
import React, { useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import colors from "@/constants/colors";
import { useAuth } from "@/context/AuthContext";

export default function LoginScreen() {
  const { login, currentUser, isLoading } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  if (isLoading) return null;
  if (currentUser) return <Redirect href="/(tabs)" />;

  const handleLogin = async () => {
    if (!username.trim() || !password) {
      setError("يرجى إدخال اسم المستخدم وكلمة المرور");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const ok = await login(username.trim(), password);
      if (ok) {
        router.replace("/(tabs)");
      } else {
        setError("اسم المستخدم أو كلمة المرور غير صحيحة");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.root}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <ScrollView
        contentContainerStyle={[styles.container, { paddingTop: insets.top + 60, paddingBottom: insets.bottom + 40 }]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.logoBox}>
          <View style={styles.logoCircle}>
            <Feather name="truck" size={44} color="#fff" />
          </View>
          <Text style={styles.appTitle}>نظام تتبع السائقين</Text>
          <Text style={styles.appSubtitle}>سجّل دخولك للمتابعة</Text>
        </View>

        <View style={styles.card}>
          <View style={styles.fieldWrapper}>
            <Text style={styles.fieldLabel}>اسم المستخدم</Text>
            <View style={styles.inputRow}>
              <Feather name="user" size={18} color={colors.light.mutedForeground} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                value={username}
                onChangeText={setUsername}
                placeholder="أدخل اسم المستخدم"
                placeholderTextColor={colors.light.mutedForeground}
                autoCapitalize="none"
                autoCorrect={false}
                textAlign="right"
                returnKeyType="next"
              />
            </View>
          </View>

          <View style={styles.fieldWrapper}>
            <Text style={styles.fieldLabel}>كلمة المرور</Text>
            <View style={styles.inputRow}>
              <TouchableOpacity onPress={() => setShowPass((v) => !v)} style={styles.inputIcon}>
                <Feather name={showPass ? "eye-off" : "eye"} size={18} color={colors.light.mutedForeground} />
              </TouchableOpacity>
              <TextInput
                style={styles.input}
                value={password}
                onChangeText={setPassword}
                placeholder="أدخل كلمة المرور"
                placeholderTextColor={colors.light.mutedForeground}
                secureTextEntry={!showPass}
                textAlign="right"
                returnKeyType="done"
                onSubmitEditing={handleLogin}
              />
            </View>
          </View>

          {error !== "" && (
            <View style={styles.errorBox}>
              <Feather name="alert-circle" size={15} color={colors.light.destructive} />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          )}

          <TouchableOpacity
            style={[styles.loginBtn, loading && styles.loginBtnDisabled]}
            onPress={handleLogin}
            disabled={loading}
            activeOpacity={0.85}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <>
                <Feather name="log-in" size={18} color="#fff" />
                <Text style={styles.loginBtnText}>تسجيل الدخول</Text>
              </>
            )}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.light.headerBg },
  container: { paddingHorizontal: 24, alignItems: "stretch" },
  logoBox: { alignItems: "center", marginBottom: 40 },
  logoCircle: {
    width: 96, height: 96, borderRadius: 48,
    backgroundColor: "rgba(255,255,255,0.2)",
    alignItems: "center", justifyContent: "center",
    marginBottom: 20, borderWidth: 2, borderColor: "rgba(255,255,255,0.3)",
  },
  appTitle: { fontSize: 28, fontWeight: "800" as const, color: "#fff", textAlign: "center", marginBottom: 8 },
  appSubtitle: { fontSize: 15, color: "rgba(255,255,255,0.75)", textAlign: "center" },
  card: {
    backgroundColor: "#fff", borderRadius: 20, padding: 24,
    shadowColor: "#000", shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15, shadowRadius: 16, elevation: 8,
  },
  fieldWrapper: { marginBottom: 20 },
  fieldLabel: { fontSize: 14, fontWeight: "600" as const, color: colors.light.foreground, textAlign: "right", marginBottom: 8 },
  inputRow: {
    flexDirection: "row", alignItems: "center",
    borderWidth: 1.5, borderColor: colors.light.border,
    borderRadius: colors.radius, paddingHorizontal: 12,
    backgroundColor: colors.light.background,
  },
  inputIcon: { padding: 4 },
  input: { flex: 1, paddingVertical: 13, fontSize: 15, color: colors.light.foreground, textAlign: "right", marginRight: 8 },
  errorBox: {
    flexDirection: "row", alignItems: "center", justifyContent: "flex-end",
    gap: 6, backgroundColor: "#FEF2F2", borderRadius: 8, padding: 10, marginBottom: 16,
  },
  errorText: { fontSize: 13, color: colors.light.destructive, textAlign: "right" },
  loginBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 8, backgroundColor: colors.light.primary, borderRadius: colors.radius,
    paddingVertical: 15, marginTop: 4,
  },
  loginBtnDisabled: { opacity: 0.6 },
  loginBtnText: { color: "#fff", fontSize: 17, fontWeight: "700" as const },
});
