import { Feather } from "@expo/vector-icons";
import * as FileSystem from "expo-file-system";
import * as Sharing from "expo-sharing";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { CustomPicker } from "@/components/CustomPicker";
import { Toast, useToast } from "@/components/Toast";
import colors from "@/constants/colors";
import { Trip, useApp } from "@/context/AppContext";
import { SHIFTS, formatDatetime, tripStationLabel } from "@/utils/vehicleData";

const ALL_SHIFTS = [{ label: "الكل", value: "" }, ...SHIFTS];

function buildCsv(rows: Trip[]): string {
  const headers = ["رقم المركبة", "نوع المركبة", "السائق", "الوردية", "المحطة", "من (تاريخ + وقت)", "إلى (تاريخ + وقت)"];
  const escape = (v: string) => `"${v.replace(/"/g, '""')}"`;
  const lines = [
    headers.map(escape).join(","),
    ...rows.map((t) =>
      [
        t.vehicle,
        t.vehicleType,
        t.driverName,
        t.shift,
        tripStationLabel(t),
        formatDatetime(t.startDatetime),
        t.endDatetime ? formatDatetime(t.endDatetime) : "نشطة",
      ].map(escape).join(",")
    ),
  ];
  return "\uFEFF" + lines.join("\n");
}

async function exportCsv(rows: Trip[], show: (msg: string, type: any) => void) {
  const csv = buildCsv(rows);
  const filename = `رحلات_${new Date().toISOString().slice(0, 10)}.csv`;

  if (Platform.OS === "web") {
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
    show("تم تحميل الملف", "success");
    return;
  }

  try {
    const path = `${FileSystem.cacheDirectory}${filename}`;
    await FileSystem.writeAsStringAsync(path, csv, { encoding: FileSystem.EncodingType.UTF8 });
    const canShare = await Sharing.isAvailableAsync();
    if (canShare) {
      await Sharing.shareAsync(path, { mimeType: "text/csv", dialogTitle: "مشاركة التقرير" });
    } else {
      show("المشاركة غير متاحة على هذا الجهاز", "error");
    }
  } catch {
    show("حدث خطأ أثناء التصدير", "error");
  }
}

export default function SearchScreen() {
  const { trips } = useApp();
  const insets = useSafeAreaInsets();
  const { state: toast, show: showToast, hide: hideToast } = useToast();

  const [driverInput, setDriverInput] = useState("");
  const [vehicleInput, setVehicleInput] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [shiftFilter, setShiftFilter] = useState("");
  const [results, setResults] = useState<Trip[] | null>(null);
  const [exporting, setExporting] = useState(false);

  const topPad = 0;

  const handleSearch = () => {
    let filtered = [...trips];
    if (driverInput.trim()) filtered = filtered.filter((t) => t.driverName.toLowerCase().includes(driverInput.trim().toLowerCase()));
    if (vehicleInput.trim()) filtered = filtered.filter((t) => t.vehicle.toLowerCase().includes(vehicleInput.trim().toLowerCase()));
    if (shiftFilter) filtered = filtered.filter((t) => t.shift === shiftFilter);
    if (dateFrom) {
      const from = new Date(dateFrom); from.setHours(0, 0, 0, 0);
      filtered = filtered.filter((t) => new Date(t.startDatetime) >= from);
    }
    if (dateTo) {
      const to = new Date(dateTo); to.setHours(23, 59, 59, 999);
      filtered = filtered.filter((t) => new Date(t.startDatetime) <= to);
    }
    filtered.sort((a, b) => new Date(b.startDatetime).getTime() - new Date(a.startDatetime).getTime());
    setResults(filtered);
  };

  const handleClear = () => {
    setDriverInput(""); setVehicleInput(""); setDateFrom(""); setDateTo(""); setShiftFilter(""); setResults(null);
  };

  const handleExport = async () => {
    if (!results || results.length === 0) { showToast("لا توجد نتائج للتصدير", "error"); return; }
    setExporting(true);
    try {
      await exportCsv(results, showToast);
    } finally {
      setExporting(false);
    }
  };

  const renderResult = (item: Trip) => (
    <View key={item.id} style={styles.resultCard}>
      <View style={styles.resultHeader}>
        <View style={[styles.statusDot, { backgroundColor: item.endDatetime ? colors.light.mutedForeground : colors.light.success }]} />
        <Text style={styles.resultType}>{item.vehicleType}</Text>
        <Text style={styles.resultVehicle}>{item.vehicle}</Text>
      </View>
      <View style={styles.resultRow}>
        <Text style={styles.resultLabel}>السائق</Text>
        <Text style={styles.resultValue}>{item.driverName}</Text>
      </View>
      <View style={styles.resultRow}>
        <Text style={styles.resultLabel}>الوردية</Text>
        <Text style={styles.resultValue}>{item.shift}</Text>
      </View>
      <View style={styles.resultRow}>
        <Text style={styles.resultLabel}>المحطة</Text>
        <Text style={styles.resultValue}>{tripStationLabel(item)}</Text>
      </View>
      <View style={styles.resultRow}>
        <Text style={styles.resultLabel}>من</Text>
        <Text style={styles.resultValue}>{formatDatetime(item.startDatetime)}</Text>
      </View>
      <View style={styles.resultRow}>
        <Text style={styles.resultLabel}>إلى</Text>
        <Text style={[styles.resultValue, !item.endDatetime && { color: colors.light.success }]}>
          {item.endDatetime ? formatDatetime(item.endDatetime) : "نشطة الآن"}
        </Text>
      </View>
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: colors.light.background }}>
      <View style={[styles.header, { paddingTop: topPad + 12 }]}>
        <Text style={styles.headerTitle}>البحث</Text>
      </View>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 120 }]}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.card}>
          <Text style={styles.cardTitle}>فلاتر البحث</Text>

          <Text style={styles.fieldLabel}>اسم السائق</Text>
          <TextInput style={styles.input} value={driverInput} onChangeText={setDriverInput} placeholder="ابحث باسم السائق" placeholderTextColor={colors.light.mutedForeground} textAlign="right" />

          <Text style={styles.fieldLabel}>رقم المركبة</Text>
          <TextInput style={styles.input} value={vehicleInput} onChangeText={setVehicleInput} placeholder="مثال: T5 أو P01" placeholderTextColor={colors.light.mutedForeground} textAlign="right" />

          <View style={styles.dateRow}>
            <View style={styles.dateField}>
              <Text style={styles.fieldLabel}>التاريخ إلى</Text>
              <TextInput style={styles.input} value={dateTo} onChangeText={setDateTo} placeholder="YYYY-MM-DD" placeholderTextColor={colors.light.mutedForeground} textAlign="right" />
            </View>
            <View style={styles.dateField}>
              <Text style={styles.fieldLabel}>التاريخ من</Text>
              <TextInput style={styles.input} value={dateFrom} onChangeText={setDateFrom} placeholder="YYYY-MM-DD" placeholderTextColor={colors.light.mutedForeground} textAlign="right" />
            </View>
          </View>

          <CustomPicker label="الوردية" value={shiftFilter} options={ALL_SHIFTS} onSelect={setShiftFilter} placeholder="كل الورديات" />

          <View style={styles.btnRow}>
            <TouchableOpacity style={styles.clearBtn} onPress={handleClear} activeOpacity={0.7}>
              <Feather name="x" size={15} color={colors.light.mutedForeground} />
              <Text style={styles.clearBtnText}>مسح</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.searchBtn} onPress={handleSearch} activeOpacity={0.7}>
              <Feather name="search" size={15} color="#fff" />
              <Text style={styles.searchBtnText}>بحث</Text>
            </TouchableOpacity>
          </View>
        </View>

        {results !== null && (
          <View style={styles.resultsSection}>
            <View style={styles.resultsHeader}>
              {results.length > 0 && (
                <TouchableOpacity
                  style={[styles.exportBtn, exporting && { opacity: 0.6 }]}
                  onPress={handleExport}
                  disabled={exporting}
                  activeOpacity={0.8}
                >
                  {exporting ? (
                    <ActivityIndicator size="small" color="#fff" />
                  ) : (
                    <>
                      <Feather name="download" size={14} color="#fff" />
                      <Text style={styles.exportBtnText}>تصدير Excel</Text>
                    </>
                  )}
                </TouchableOpacity>
              )}
              <Text style={styles.resultsCount}>
                {results.length === 0 ? "لا توجد نتائج" : `${results.length} نتيجة`}
              </Text>
            </View>
            {results.map(renderResult)}
          </View>
        )}
      </ScrollView>
      <Toast message={toast.message} type={toast.type} visible={toast.visible} onHide={hideToast} />
    </View>
  );
}

const styles = StyleSheet.create({
  header: { backgroundColor: colors.light.headerBg, paddingHorizontal: 20, paddingBottom: 16 },
  headerTitle: { fontSize: 22, fontWeight: "700" as const, color: "#fff", textAlign: "right" },
  content: { padding: 16, gap: 12 },
  card: {
    backgroundColor: colors.light.card, borderRadius: colors.radius, padding: 16,
    shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 2,
  },
  cardTitle: { fontSize: 16, fontWeight: "700" as const, color: colors.light.foreground, textAlign: "right", marginBottom: 16 },
  fieldLabel: { fontSize: 14, fontWeight: "600" as const, color: colors.light.foreground, textAlign: "right", marginBottom: 8 },
  input: {
    backgroundColor: colors.light.background, borderWidth: 1, borderColor: colors.light.border,
    borderRadius: colors.radius, paddingHorizontal: 14, paddingVertical: 12,
    fontSize: 15, color: colors.light.foreground, marginBottom: 16,
  },
  dateRow: { flexDirection: "row", gap: 12 },
  dateField: { flex: 1 },
  btnRow: { flexDirection: "row", gap: 10, marginTop: 4 },
  clearBtn: {
    flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 6, paddingVertical: 13, borderRadius: colors.radius,
    borderWidth: 1, borderColor: colors.light.border,
  },
  clearBtnText: { fontSize: 14, fontWeight: "600" as const, color: colors.light.mutedForeground },
  searchBtn: {
    flex: 2, flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 8, paddingVertical: 13, borderRadius: colors.radius, backgroundColor: colors.light.primary,
  },
  searchBtnText: { fontSize: 14, fontWeight: "700" as const, color: "#fff" },
  resultsSection: { gap: 10 },
  resultsHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 2, marginBottom: 4 },
  resultsCount: { fontSize: 14, fontWeight: "600" as const, color: colors.light.mutedForeground, textAlign: "right" },
  exportBtn: {
    flexDirection: "row", alignItems: "center", gap: 6,
    backgroundColor: colors.light.success, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 10,
  },
  exportBtnText: { color: "#fff", fontSize: 13, fontWeight: "700" as const },
  resultCard: {
    backgroundColor: colors.light.card, borderRadius: colors.radius, padding: 14,
    shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1,
  },
  resultHeader: {
    flexDirection: "row", alignItems: "center", justifyContent: "flex-end",
    gap: 8, marginBottom: 10, paddingBottom: 10,
    borderBottomWidth: 1, borderBottomColor: colors.light.border,
  },
  statusDot: { width: 8, height: 8, borderRadius: 4, marginRight: "auto" as any },
  resultVehicle: { fontSize: 18, fontWeight: "800" as const, color: colors.light.foreground },
  resultType: {
    fontSize: 12, fontWeight: "600" as const, color: colors.light.primary,
    backgroundColor: colors.light.secondary, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6,
  },
  resultRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 5, alignItems: "center" },
  resultLabel: { fontSize: 13, color: colors.light.mutedForeground },
  resultValue: { fontSize: 13, fontWeight: "600" as const, color: colors.light.foreground, textAlign: "right", flex: 1, marginRight: 8, writingDirection: "rtl" },
});
