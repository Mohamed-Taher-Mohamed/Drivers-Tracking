import { Feather } from "@expo/vector-icons";
import React, { useMemo, useState } from "react";
import {
  FlatList,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import colors from "@/constants/colors";
import { Trip, useApp } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";
import { formatDatetime, tripStationLabel } from "@/utils/vehicleData";

type DetailMode = "total" | "active" | "ended" | null;

function todayStart() {
  const d = new Date(); d.setHours(0, 0, 0, 0); return d;
}
function yearStart() {
  const d = new Date(); d.setMonth(0, 1); d.setHours(0, 0, 0, 0); return d;
}

function TripRow({ trip }: { trip: Trip }) {
  return (
    <View style={tripStyles.row}>
      <View style={tripStyles.right}>
        <Text style={tripStyles.vehicle}>{trip.vehicle} <Text style={tripStyles.type}>({trip.vehicleType})</Text></Text>
        <Text style={tripStyles.driver}>{trip.driverName}</Text>
        <Text style={tripStyles.station}>{tripStationLabel(trip)}</Text>
      </View>
      <View style={[tripStyles.dot, { backgroundColor: trip.endDatetime ? colors.light.mutedForeground : colors.light.success }]} />
    </View>
  );
}

function DetailModal({
  visible,
  mode,
  trips,
  isAdmin,
  userId,
  onClose,
}: {
  visible: boolean;
  mode: DetailMode;
  trips: Trip[];
  isAdmin: boolean;
  userId: string;
  onClose: () => void;
}) {
  const insets = useSafeAreaInsets();
  const [subTab, setSubTab] = useState<"today" | "year">("today");

  const todayS = todayStart();
  const yearS = yearStart();

  const data = useMemo(() => {
    if (!mode) return { main: [], sub: [] };

    if (mode === "total") {
      const today = trips.filter((t) => new Date(t.startDatetime) >= todayS);
      const year = trips.filter((t) => new Date(t.startDatetime) >= yearS);
      return { main: today, sub: year };
    }

    if (mode === "active") {
      const active = trips.filter((t) => !t.endDatetime && new Date(t.startDatetime) >= todayS);
      if (isAdmin) return { main: active, sub: [] };
      return { main: active.filter((t) => t.userId === userId), sub: [] };
    }

    if (mode === "ended") {
      const ended = trips.filter((t) => !!t.endDatetime && new Date(t.startDatetime) >= todayS);
      if (isAdmin) return { main: ended, sub: [] };
      return { main: ended.filter((t) => t.userId === userId), sub: [] };
    }

    return { main: [], sub: [] };
  }, [mode, trips, isAdmin, userId]);

  const isTotal = mode === "total";
  const displayList = isTotal ? (subTab === "today" ? data.main : data.sub) : data.main;

  const title =
    mode === "total" ? "إجمالي الرحلات" :
    mode === "active" ? "الرحلات النشطة" :
    mode === "ended" ? "الرحلات المنتهية" : "";

  const adminNote = isAdmin && (mode === "active" || mode === "ended") ? "جميع المستخدمين" : mode === "active" || mode === "ended" ? "رحلاتي" : "";

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable style={detailStyles.overlay} onPress={onClose}>
        <View style={[detailStyles.sheet, { paddingBottom: insets.bottom + 16 }]} onStartShouldSetResponder={() => true}>
          <View style={detailStyles.handle} />
          <View style={detailStyles.header}>
            <TouchableOpacity onPress={onClose} style={detailStyles.closeBtn}>
              <Feather name="x" size={20} color={colors.light.foreground} />
            </TouchableOpacity>
            <View style={detailStyles.titleWrap}>
              <Text style={detailStyles.title}>{title}</Text>
              {adminNote ? <Text style={detailStyles.subtitle}>{adminNote}</Text> : null}
            </View>
          </View>

          {isTotal && (
            <View style={detailStyles.subTabRow}>
              {([["today", "رحلات اليوم"], ["year", "كل السنة"]] as const).map(([v, l]) => (
                <TouchableOpacity
                  key={v}
                  style={[detailStyles.subTab, subTab === v && detailStyles.subTabActive]}
                  onPress={() => setSubTab(v)}
                  activeOpacity={0.7}
                >
                  <Text style={[detailStyles.subTabText, subTab === v && detailStyles.subTabTextActive]}>{l}</Text>
                </TouchableOpacity>
              ))}
            </View>
          )}

          <View style={detailStyles.countRow}>
            <Text style={detailStyles.count}>{displayList.length} رحلة</Text>
          </View>

          {displayList.length === 0 ? (
            <View style={detailStyles.empty}>
              <Feather name="inbox" size={40} color={colors.light.mutedForeground} />
              <Text style={detailStyles.emptyText}>لا توجد رحلات</Text>
            </View>
          ) : (
            <FlatList
              data={displayList.slice().sort((a, b) => new Date(b.startDatetime).getTime() - new Date(a.startDatetime).getTime())}
              keyExtractor={(t) => t.id}
              showsVerticalScrollIndicator={false}
              renderItem={({ item }) => <TripRow trip={item} />}
              contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 8 }}
            />
          )}
        </View>
      </Pressable>
    </Modal>
  );
}

function HorizBar({ label, value, max, color }: { label: string; value: number; max: number; color: string }) {
  const pct = max > 0 ? value / max : 0;
  return (
    <View style={barStyles.row}>
      <Text style={barStyles.val}>{value}</Text>
      <View style={barStyles.track}>
        <View style={[barStyles.fill, { width: `${Math.max(pct * 100, 4)}%` as any, backgroundColor: color }]} />
      </View>
      <Text style={barStyles.label}>{label}</Text>
    </View>
  );
}

function StatCard({ icon, label, value, color, onPress }: {
  icon: string; label: string; value: string | number; color: string; onPress?: () => void;
}) {
  return (
    <TouchableOpacity
      style={[cardStyles.card, { borderLeftColor: color }]}
      onPress={onPress}
      activeOpacity={onPress ? 0.75 : 1}
    >
      <View style={cardStyles.info}>
        <Text style={cardStyles.val}>{value}</Text>
        <Text style={cardStyles.label}>{label}</Text>
        {onPress && (
          <Text style={[cardStyles.tapHint, { color }]}>اضغط للتفاصيل ←</Text>
        )}
      </View>
      <View style={[cardStyles.iconBox, { backgroundColor: color + "22" }]}>
        <Feather name={icon as any} size={22} color={color} />
      </View>
    </TouchableOpacity>
  );
}

type Period = "today" | "week" | "month" | "all";
const PERIOD_OPTS: { label: string; value: Period }[] = [
  { label: "اليوم", value: "today" },
  { label: "أسبوع", value: "week" },
  { label: "شهر", value: "month" },
  { label: "الكل", value: "all" },
];
const CHART_COLORS = [colors.light.primary, "#10B981", "#F59E0B", "#EF4444", "#8B5CF6", "#EC4899"];

function filterByPeriod(trips: Trip[], period: Period) {
  if (period === "all") return trips;
  const s = new Date();
  if (period === "today") s.setHours(0, 0, 0, 0);
  else if (period === "week") { s.setDate(s.getDate() - 6); s.setHours(0, 0, 0, 0); }
  else if (period === "month") { s.setDate(s.getDate() - 29); s.setHours(0, 0, 0, 0); }
  return trips.filter((t) => new Date(t.startDatetime) >= s);
}

export default function StatsScreen() {
  const { trips } = useApp();
  const { currentUser } = useAuth();
  const insets = useSafeAreaInsets();
  const topPad = 0;
  const isAdmin = currentUser?.role === "admin";
  const userId = currentUser?.id || "";

  const [period, setPeriod] = useState<Period>("week");
  const [detailMode, setDetailMode] = useState<DetailMode>(null);

  const filtered = useMemo(() => filterByPeriod(trips, period), [trips, period]);

  const stats = useMemo(() => {
    const active = filtered.filter((t) => !t.endDatetime).length;
    const ended = filtered.filter((t) => !!t.endDatetime).length;
    const total = filtered.length;
    const byShift: Record<string, number> = {};
    const byType: Record<string, number> = {};
    const byDriver: Record<string, number> = {};
    const byVehicle: Record<string, number> = {};
    for (const t of filtered) {
      byShift[t.shift] = (byShift[t.shift] || 0) + 1;
      byType[t.vehicleType] = (byType[t.vehicleType] || 0) + 1;
      byDriver[t.driverName] = (byDriver[t.driverName] || 0) + 1;
      byVehicle[t.vehicle] = (byVehicle[t.vehicle] || 0) + 1;
    }
    const completed = filtered.filter((t) => t.endDatetime);
    const avgDurationMins = completed.length
      ? Math.round(completed.reduce((s, t) => s + (new Date(t.endDatetime!).getTime() - new Date(t.startDatetime).getTime()), 0) / completed.length / 60000)
      : null;
    return { total, active, ended, byShift, byType, byDriver, byVehicle, avgDurationMins };
  }, [filtered]);

  const topBy = (map: Record<string, number>, n = 6) =>
    Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, n);

  const topDrivers = topBy(stats.byDriver, 6);
  const topVehicles = topBy(stats.byVehicle, 5);
  const maxShift = Math.max(...Object.values(stats.byShift), 1);
  const maxType = Math.max(...Object.values(stats.byType), 1);
  const maxDriver = topDrivers[0]?.[1] ?? 1;
  const maxVehicle = topVehicles[0]?.[1] ?? 1;

  return (
    <View style={{ flex: 1, backgroundColor: colors.light.background }}>
      <View style={[styles.header, { paddingTop: topPad + 12 }]}>
        <Text style={styles.headerTitle}>الإحصائيات</Text>
      </View>

      <View style={styles.periodBar}>
        {PERIOD_OPTS.map((opt) => (
          <TouchableOpacity
            key={opt.value}
            style={[styles.periodBtn, period === opt.value && styles.periodBtnActive]}
            onPress={() => setPeriod(opt.value)}
            activeOpacity={0.7}
          >
            <Text style={[styles.periodBtnText, period === opt.value && styles.periodBtnTextActive]}>
              {opt.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 100 }]}
      >
        <View style={styles.cardsGrid}>
          <StatCard icon="list" label="إجمالي الرحلات" value={stats.total} color={colors.light.primary} onPress={() => setDetailMode("total")} />
          <StatCard icon="activity" label="رحلات نشطة" value={stats.active} color={colors.light.success} onPress={() => setDetailMode("active")} />
          <StatCard icon="check-circle" label="رحلات منتهية" value={stats.ended} color="#8B5CF6" onPress={() => setDetailMode("ended")} />
          <StatCard icon="clock" label="متوسط المدة" value={stats.avgDurationMins !== null ? `${stats.avgDurationMins} د` : "—"} color="#F59E0B" />
        </View>

        {Object.keys(stats.byShift).length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>الرحلات حسب الوردية</Text>
            {Object.entries(stats.byShift).sort((a, b) => b[1] - a[1]).map(([shift, count], i) => (
              <HorizBar key={shift} label={shift} value={count} max={maxShift} color={CHART_COLORS[i % CHART_COLORS.length]!} />
            ))}
          </View>
        )}

        {Object.keys(stats.byType).length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>الرحلات حسب نوع المركبة</Text>
            {Object.entries(stats.byType).sort((a, b) => b[1] - a[1]).map(([type, count], i) => (
              <HorizBar key={type} label={type} value={count} max={maxType} color={CHART_COLORS[i % CHART_COLORS.length]!} />
            ))}
          </View>
        )}

        {topDrivers.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>أكثر السائقين نشاطاً</Text>
            {topDrivers.map(([driver, count], i) => (
              <HorizBar key={driver} label={driver} value={count} max={maxDriver} color={CHART_COLORS[i % CHART_COLORS.length]!} />
            ))}
          </View>
        )}

        {topVehicles.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>أكثر المركبات استخداماً</Text>
            {topVehicles.map(([vehicle, count], i) => (
              <HorizBar key={vehicle} label={vehicle} value={count} max={maxVehicle} color={CHART_COLORS[i % CHART_COLORS.length]!} />
            ))}
          </View>
        )}

        {stats.total === 0 && (
          <View style={styles.empty}>
            <Feather name="bar-chart-2" size={48} color={colors.light.mutedForeground} />
            <Text style={styles.emptyText}>لا توجد بيانات في هذه الفترة</Text>
          </View>
        )}
      </ScrollView>

      <DetailModal
        visible={detailMode !== null}
        mode={detailMode}
        trips={trips}
        isAdmin={isAdmin}
        userId={userId}
        onClose={() => setDetailMode(null)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  header: { backgroundColor: colors.light.headerBg, paddingHorizontal: 20, paddingBottom: 16 },
  headerTitle: { fontSize: 22, fontWeight: "700" as const, color: "#fff", textAlign: "right" },
  periodBar: {
    flexDirection: "row", backgroundColor: colors.light.card,
    paddingHorizontal: 12, paddingVertical: 10, gap: 8,
    borderBottomWidth: 1, borderBottomColor: colors.light.border,
  },
  periodBtn: {
    flex: 1, paddingVertical: 8, borderRadius: 10, alignItems: "center",
    backgroundColor: colors.light.background, borderWidth: 1, borderColor: colors.light.border,
  },
  periodBtnActive: { backgroundColor: colors.light.primary, borderColor: colors.light.primary },
  periodBtnText: { fontSize: 13, fontWeight: "600" as const, color: colors.light.mutedForeground },
  periodBtnTextActive: { color: "#fff" },
  content: { padding: 16, gap: 12 },
  cardsGrid: { gap: 10 },
  section: {
    backgroundColor: colors.light.card, borderRadius: colors.radius, padding: 16,
    shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 2,
  },
  sectionTitle: { fontSize: 15, fontWeight: "700" as const, color: colors.light.foreground, textAlign: "right", marginBottom: 14 },
  empty: { alignItems: "center", justifyContent: "center", paddingVertical: 60, gap: 12 },
  emptyText: { fontSize: 15, color: colors.light.mutedForeground, textAlign: "center" },
});

const barStyles = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", marginBottom: 10, gap: 8 },
  label: { fontSize: 13, fontWeight: "600" as const, color: colors.light.foreground, textAlign: "right", flexShrink: 1, minWidth: 80, maxWidth: 130 },
  track: { flex: 1, height: 12, backgroundColor: colors.light.secondary, borderRadius: 6, overflow: "hidden" },
  fill: { height: "100%", borderRadius: 6 },
  val: { width: 28, fontSize: 13, fontWeight: "700" as const, color: colors.light.foreground, textAlign: "center" },
});

const cardStyles = StyleSheet.create({
  card: {
    backgroundColor: colors.light.card, borderRadius: colors.radius, padding: 16,
    borderLeftWidth: 4, flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 2,
  },
  iconBox: { width: 48, height: 48, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  info: { flex: 1, alignItems: "flex-end" },
  val: { fontSize: 28, fontWeight: "800" as const, color: colors.light.foreground, textAlign: "right" },
  label: { fontSize: 13, color: colors.light.mutedForeground, textAlign: "right", marginTop: 2 },
  tapHint: { fontSize: 11, fontWeight: "600" as const, textAlign: "right", marginTop: 4, opacity: 0.8 },
});

const detailStyles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.45)", justifyContent: "flex-end" },
  sheet: {
    backgroundColor: colors.light.card,
    borderTopLeftRadius: 24, borderTopRightRadius: 24,
    maxHeight: "82%",
  },
  handle: {
    width: 40, height: 4, backgroundColor: colors.light.border,
    borderRadius: 2, alignSelf: "center", marginTop: 10, marginBottom: 4,
  },
  header: {
    flexDirection: "row", alignItems: "center", paddingHorizontal: 20, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: colors.light.border, gap: 10,
  },
  closeBtn: { padding: 4 },
  titleWrap: { flex: 1, alignItems: "flex-end" },
  title: { fontSize: 17, fontWeight: "700" as const, color: colors.light.foreground, textAlign: "right" },
  subtitle: { fontSize: 12, color: colors.light.mutedForeground, textAlign: "right", marginTop: 2 },
  subTabRow: {
    flexDirection: "row", paddingHorizontal: 16, paddingVertical: 10, gap: 10,
    borderBottomWidth: 1, borderBottomColor: colors.light.border,
  },
  subTab: {
    flex: 1, paddingVertical: 9, borderRadius: 10, alignItems: "center",
    backgroundColor: colors.light.background, borderWidth: 1, borderColor: colors.light.border,
  },
  subTabActive: { backgroundColor: colors.light.primary, borderColor: colors.light.primary },
  subTabText: { fontSize: 14, fontWeight: "600" as const, color: colors.light.mutedForeground },
  subTabTextActive: { color: "#fff" },
  countRow: { paddingHorizontal: 20, paddingVertical: 8, alignItems: "flex-end" },
  count: { fontSize: 13, color: colors.light.mutedForeground, fontWeight: "600" as const },
  empty: { alignItems: "center", justifyContent: "center", paddingVertical: 50, gap: 12 },
  emptyText: { fontSize: 15, color: colors.light.mutedForeground },
});

const tripStyles = StyleSheet.create({
  row: {
    flexDirection: "row", alignItems: "center", justifyContent: "flex-end",
    paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.light.border, gap: 10,
  },
  dot: { width: 9, height: 9, borderRadius: 5, flexShrink: 0 },
  right: { flex: 1, alignItems: "flex-end" },
  vehicle: { fontSize: 15, fontWeight: "700" as const, color: colors.light.foreground },
  type: { fontSize: 12, color: colors.light.mutedForeground, fontWeight: "400" as const },
  driver: { fontSize: 13, color: colors.light.mutedForeground, marginTop: 2 },
  station: { fontSize: 12, color: colors.light.primary, marginTop: 2 },
});
