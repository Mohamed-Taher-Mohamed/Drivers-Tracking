import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { TripEditModal } from "@/components/TripEditModal";
import { Toast, useToast } from "@/components/Toast";
import colors from "@/constants/colors";
import { Trip, useApp } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";
import { formatDatetime } from "@/utils/vehicleData";

export default function EndTripScreen() {
  const { activeTrips, myActiveTrips, endTrip, editTrip, drivers, canEdit } = useApp();
  const { currentUser } = useAuth();
  const insets = useSafeAreaInsets();
  const { state: toast, show: showToast, hide: hideToast } = useToast();

  const isAdmin = currentUser?.role === "admin";
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);
  const [confirmVisible, setConfirmVisible] = useState(false);
  const [editingTrip, setEditingTrip] = useState<Trip | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const driverOptions = drivers.map((d) => ({ label: d.name, value: d.name }));

  const displayedTrips = isAdmin ? activeTrips : myActiveTrips;

  const handleEndPress = (trip: Trip) => {
    setSelectedTrip(trip);
    setConfirmVisible(true);
  };

  const handleConfirm = async () => {
    if (!selectedTrip) return;
    setSubmitting(true);
    try {
      await endTrip(selectedTrip.id);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      showToast(`تم تسجيل نزول ${selectedTrip.driverName} من ${selectedTrip.vehicle}`, "success");
      setConfirmVisible(false);
      setSelectedTrip(null);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.light.background }}>
      <View style={[styles.header]}>
        <Text style={styles.headerTitle}>تسجيل نزول</Text>
        <View style={styles.badge}>
          <Text style={styles.badgeText}>{displayedTrips.length} نشطة</Text>
        </View>
      </View>

      {!isAdmin && activeTrips.length > 0 && myActiveTrips.length === 0 && (
        <View style={styles.infoBar}>
          <Feather name="info" size={14} color={colors.light.primary} />
          <Text style={styles.infoText}>يوجد {activeTrips.length} رحلة نشطة — تظهر لك رحلاتك فقط</Text>
        </View>
      )}

      {displayedTrips.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Feather name="inbox" size={56} color={colors.light.border} />
          <Text style={styles.emptyTitle}>
            {isAdmin ? "لا توجد رحلات نشطة" : "لا توجد رحلات نشطة لك"}
          </Text>
          <Text style={styles.emptySubtitle}>
            {isAdmin ? "قم بتسجيل ركوب أولاً" : "سجّل ركوباً من تبويب ركوب"}
          </Text>
        </View>
      ) : (
        <FlatList
          data={displayedTrips}
          keyExtractor={(item) => item.id}
          contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 120 }]}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => {
            const editable = canEdit(item, isAdmin);
            return (
              <View style={styles.tripCard}>
                <View style={styles.tripHeader}>
                  <View style={styles.tripActions}>
                    {editable && (
                      <TouchableOpacity style={styles.editBtn} onPress={() => setEditingTrip(item)} activeOpacity={0.7}>
                        <Feather name="edit-2" size={14} color={colors.light.primary} />
                      </TouchableOpacity>
                    )}
                    <TouchableOpacity style={styles.endBtn} onPress={() => handleEndPress(item)} activeOpacity={0.7}>
                      <Feather name="log-out" size={15} color="#fff" />
                      <Text style={styles.endBtnText}>نزول</Text>
                    </TouchableOpacity>
                  </View>
                  <View style={styles.tripMainInfo}>
                    <View style={styles.vehicleRow}>
                      <View style={styles.activeIndicator} />
                      <Text style={styles.vehicleNumber}>{item.vehicle}</Text>
                    </View>
                    <Text style={styles.driverName}>{item.driverName}</Text>
                    <Text style={styles.vehicleType}>{item.vehicleType}</Text>
                  </View>
                </View>
                <View style={styles.tripDetails}>
                  <View style={styles.detailItem}>
                    <Text style={styles.detailValue}>{item.shift}</Text>
                    <Text style={styles.detailLabel}>الوردية</Text>
                  </View>
                  <View style={styles.detailDivider} />
                  <View style={styles.detailItem}>
                    <Text style={styles.detailValue} numberOfLines={1}>{item.station}</Text>
                    <Text style={styles.detailLabel}>المحطة</Text>
                  </View>
                  <View style={styles.detailDivider} />
                  <View style={styles.detailItem}>
                    <Text style={styles.detailValue}>
                      {new Date(item.startDatetime).toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" })}
                    </Text>
                    <Text style={styles.detailLabel}>وقت الركوب</Text>
                  </View>
                </View>
                {!item.synced && (
                  <View style={styles.unsyncedBadge}>
                    <Feather name="cloud-off" size={11} color={colors.light.mutedForeground} />
                    <Text style={styles.unsyncedText}>لم تُرفع</Text>
                  </View>
                )}
              </View>
            );
          }}
        />
      )}

      <Modal visible={confirmVisible} transparent animationType="fade" onRequestClose={() => setConfirmVisible(false)}>
        <View style={styles.overlay}>
          <View style={[styles.confirmModal, { paddingBottom: insets.bottom + 16 }]}>
            <Feather name="alert-circle" size={44} color={colors.light.warning} style={styles.confirmIcon} />
            <Text style={styles.confirmTitle}>تأكيد تسجيل النزول</Text>
            {selectedTrip && (
              <>
                <Text style={styles.confirmText}>السائق: <Text style={styles.confirmHighlight}>{selectedTrip.driverName}</Text></Text>
                <Text style={styles.confirmText}>المركبة: <Text style={styles.confirmHighlight}>{selectedTrip.vehicle}</Text></Text>
              </>
            )}
            <View style={styles.confirmActions}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => { setConfirmVisible(false); setSelectedTrip(null); }} activeOpacity={0.7}>
                <Text style={styles.cancelBtnText}>إلغاء</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.confirmBtn, submitting && { opacity: 0.6 }]} onPress={handleConfirm} disabled={submitting} activeOpacity={0.7}>
                {submitting ? <ActivityIndicator color="#fff" size="small" /> : <Text style={styles.confirmBtnText}>تأكيد النزول</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <TripEditModal
        trip={editingTrip}
        visible={editingTrip !== null}
        driverOptions={driverOptions}
        onClose={() => setEditingTrip(null)}
        onSave={async (id, data) => {
          await editTrip(id, data);
          showToast("تم تعديل الرحلة", "success");
          setEditingTrip(null);
        }}
      />

      <Toast message={toast.message} type={toast.type} visible={toast.visible} onHide={hideToast} />
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    backgroundColor: colors.light.headerBg,
    paddingHorizontal: 20,
    paddingBottom: 16,
    paddingTop: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  headerTitle: { fontSize: 22, fontWeight: "700" as const, color: "#fff" },
  badge: { backgroundColor: "rgba(255,255,255,0.25)", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
  badgeText: { color: "#fff", fontSize: 13, fontWeight: "600" as const },
  infoBar: {
    flexDirection: "row", alignItems: "center", justifyContent: "flex-end",
    gap: 8, backgroundColor: colors.light.secondary,
    paddingHorizontal: 16, paddingVertical: 10,
    borderBottomWidth: 1, borderBottomColor: colors.light.border,
  },
  infoText: { fontSize: 13, color: colors.light.primary, fontWeight: "500" as const, textAlign: "right", flex: 1 },
  emptyContainer: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  emptyTitle: { fontSize: 18, fontWeight: "700" as const, color: colors.light.foreground },
  emptySubtitle: { fontSize: 14, color: colors.light.mutedForeground },
  list: { padding: 16, gap: 12 },
  tripCard: {
    backgroundColor: colors.light.card, borderRadius: colors.radius, overflow: "hidden",
    shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 2,
  },
  tripHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: 14 },
  tripMainInfo: { alignItems: "flex-end", flex: 1 },
  vehicleRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  activeIndicator: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.light.success },
  vehicleNumber: { fontSize: 20, fontWeight: "800" as const, color: colors.light.foreground },
  driverName: { fontSize: 15, color: colors.light.mutedForeground, marginTop: 3, writingDirection: "rtl" },
  vehicleType: { fontSize: 12, color: colors.light.accent, marginTop: 2 },
  tripActions: { flexDirection: "column", gap: 8, alignItems: "center" },
  endBtn: {
    flexDirection: "row", alignItems: "center", gap: 5,
    backgroundColor: colors.light.destructive, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 10,
  },
  endBtnText: { color: "#fff", fontWeight: "700" as const, fontSize: 13 },
  editBtn: {
    backgroundColor: colors.light.secondary, borderRadius: 8, padding: 7,
    borderWidth: 1, borderColor: colors.light.primary + "40",
  },
  tripDetails: {
    flexDirection: "row", justifyContent: "space-around",
    borderTopWidth: 1, borderTopColor: colors.light.border, paddingVertical: 11,
  },
  detailItem: { alignItems: "center", flex: 1 },
  detailLabel: { fontSize: 11, color: colors.light.mutedForeground, marginTop: 2 },
  detailValue: { fontSize: 13, fontWeight: "600" as const, color: colors.light.foreground, writingDirection: "rtl" },
  detailDivider: { width: 1, backgroundColor: colors.light.border },
  unsyncedBadge: {
    flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 4,
    paddingVertical: 5, backgroundColor: colors.light.muted,
  },
  unsyncedText: { fontSize: 11, color: colors.light.mutedForeground },
  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.55)", alignItems: "center", justifyContent: "center", padding: 24 },
  confirmModal: { backgroundColor: colors.light.card, borderRadius: 20, padding: 24, width: "100%", alignItems: "center" },
  confirmIcon: { marginBottom: 12 },
  confirmTitle: { fontSize: 18, fontWeight: "700" as const, color: colors.light.foreground, marginBottom: 16 },
  confirmText: { fontSize: 15, color: colors.light.mutedForeground, marginBottom: 6, textAlign: "center" },
  confirmHighlight: { fontWeight: "700" as const, color: colors.light.foreground },
  confirmActions: { flexDirection: "row", gap: 12, marginTop: 24, width: "100%" },
  cancelBtn: { flex: 1, paddingVertical: 13, borderRadius: 12, borderWidth: 1, borderColor: colors.light.border, alignItems: "center" },
  cancelBtnText: { fontSize: 15, fontWeight: "600" as const, color: colors.light.foreground },
  confirmBtn: { flex: 1, paddingVertical: 13, borderRadius: 12, backgroundColor: colors.light.destructive, alignItems: "center" },
  confirmBtnText: { fontSize: 15, fontWeight: "700" as const, color: "#fff" },
});
