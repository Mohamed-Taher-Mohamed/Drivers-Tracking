import { Feather } from "@expo/vector-icons";
import { Redirect, Tabs, usePathname, useRouter } from "expo-router";
import React, { useEffect, useRef, useState } from "react";
import {
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import colors from "@/constants/colors";
import { AppProvider, useApp } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";

function Badge({ count }: { count: number }) {
  if (count === 0) return null;
  return (
    <View style={styles.badge}>
      <Text style={styles.badgeText}>{count > 9 ? "9+" : String(count)}</Text>
    </View>
  );
}

function TopTabBar() {
  const { currentUser, logout } = useAuth();
  const { liveConflictsCount } = useApp();
  const router = useRouter();
  const pathname = usePathname();
  const insets = useSafeAreaInsets();
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const [menuVisible, setMenuVisible] = useState(false);
  const isAdmin = currentUser?.role === "admin";
  const isDriver = currentUser?.role === "driver";

  const tabs = [
    { name: "index", path: "/(tabs)", label: "ركوب", icon: "log-in", badge: 0 },
    { name: "end-trip", path: "/(tabs)/end-trip", label: "نزول", icon: "log-out", badge: 0 },
    { name: "search", path: "/(tabs)/search", label: "بحث", icon: "search", badge: 0 },
    { name: "stats", path: "/(tabs)/stats", label: "إحصائيات", icon: "bar-chart-2", badge: 0 },
    { name: "drivers", path: "/(tabs)/drivers", label: "إدارة", icon: "users", badge: 0 },
    ...(isAdmin
      ? [{ name: "conflicts", path: "/(tabs)/conflicts", label: "تعارضات", icon: "alert-triangle", badge: liveConflictsCount }]
      : []),
  ];

  const isActive = (name: string) => {
    if (name === "index") {
      return pathname === "/" || pathname === "/(tabs)" || pathname === "/(tabs)/" || pathname === "/index";
    }
    return pathname.endsWith(`/${name}`);
  };

  const handleLogout = async () => {
    setMenuVisible(false);
    await logout();
    router.replace("/login");
  };

  return (
    <>
      <View style={[styles.topBar, { paddingTop: topPad }]}>
        <View style={styles.tabsRow}>
          {tabs.map((tab) => {
            const active = isActive(tab.name);
            return (
              <TouchableOpacity
                key={tab.name}
                style={styles.tabItem}
                onPress={() => router.navigate(tab.path as any)}
                activeOpacity={0.7}
              >
                <View style={[styles.tabInner, active && styles.tabInnerActive]}>
                  <View style={styles.iconWrap}>
                    <Feather
                      name={tab.icon as any}
                      size={18}
                      color={active ? "#fff" : "rgba(255,255,255,0.6)"}
                    />
                    {tab.badge > 0 && <Badge count={tab.badge} />}
                  </View>
                  <Text
                    style={[styles.tabLabel, active && styles.tabLabelActive]}
                    numberOfLines={1}
                  >
                    {tab.label}
                  </Text>
                </View>
              </TouchableOpacity>
            );
          })}
        </View>

        <TouchableOpacity
          style={styles.userBtn}
          onPress={() => setMenuVisible(true)}
          activeOpacity={0.7}
        >
          <View style={styles.userAvatar}>
            <Feather name="user" size={15} color={colors.light.primary} />
          </View>
        </TouchableOpacity>
      </View>

      <Modal
        visible={menuVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setMenuVisible(false)}
      >
        <Pressable style={styles.overlay} onPress={() => setMenuVisible(false)}>
          <View style={[styles.menuCard, { top: topPad + 60 }]}>
            <View style={styles.menuHeader}>
              <Text style={styles.menuRole}>{isAdmin ? "مدير النظام" : isDriver ? "سائق" : "مستخدم"}</Text>
              <Text style={styles.menuName}>{currentUser?.username}</Text>
            </View>
            <TouchableOpacity style={styles.logoutRow} onPress={handleLogout} activeOpacity={0.8}>
              <Text style={styles.logoutText}>تسجيل الخروج</Text>
              <Feather name="log-out" size={16} color={colors.light.destructive} />
            </TouchableOpacity>
          </View>
        </Pressable>
      </Modal>
    </>
  );
}

function ConflictAlert() {
  const { liveConflictsCount } = useApp();
  const [visible, setVisible] = useState(false);
  const prevRef = useRef(0);

  useEffect(() => {
    if (liveConflictsCount > 0 && liveConflictsCount > prevRef.current) {
      setVisible(true);
      const t = setTimeout(() => setVisible(false), 6000);
      prevRef.current = liveConflictsCount;
      return () => clearTimeout(t);
    }
    if (liveConflictsCount === 0) prevRef.current = 0;
  }, [liveConflictsCount]);

  if (!visible) return null;

  return (
    <View style={styles.alertBanner}>
      <Feather name="alert-triangle" size={15} color="#fff" />
      <Text style={styles.alertText}>
        تحذير: {liveConflictsCount} تعارض نشط — سائق أو مركبة في أكثر من رحلة
      </Text>
    </View>
  );
}

function TabsContent() {
  return (
    <View style={{ flex: 1 }}>
      <TopTabBar />
      <ConflictAlert />
      <View style={{ flex: 1 }}>
        <Tabs
          screenOptions={{ headerShown: false, tabBarStyle: { display: "none" } }}
          tabBar={() => null}
        >
          <Tabs.Screen name="index" />
          <Tabs.Screen name="end-trip" />
          <Tabs.Screen name="search" />
          <Tabs.Screen name="stats" />
          <Tabs.Screen name="drivers" />
          <Tabs.Screen name="conflicts" />
        </Tabs>
      </View>
    </View>
  );
}

export default function TabLayout() {
  const { currentUser, isLoading, deviceId } = useAuth();
  if (isLoading) return null;
  if (!currentUser) return <Redirect href="/login" />;
  return (
    <AppProvider userId={currentUser.id} deviceId={deviceId} linkedDriverName={currentUser.linkedDriverName}>
      <TabsContent />
    </AppProvider>
  );
}

const styles = StyleSheet.create({
  topBar: {
    backgroundColor: colors.light.headerBg,
    flexDirection: "row",
    alignItems: "flex-end",
    paddingHorizontal: 8,
    paddingBottom: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 8,
  },
  tabsRow: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: 3,
  },
  tabItem: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  tabInner: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 7,
    paddingHorizontal: 4,
    borderRadius: 10,
    gap: 3,
    width: "100%",
    minHeight: 52,
  },
  tabInnerActive: {
    backgroundColor: "rgba(255,255,255,0.22)",
  },
  iconWrap: {
    position: "relative",
    alignItems: "center",
    justifyContent: "center",
  },
  tabLabel: {
    fontSize: 9,
    fontWeight: "600" as const,
    color: "rgba(255,255,255,0.6)",
    textAlign: "center",
  },
  tabLabelActive: {
    color: "#fff",
  },
  badge: {
    position: "absolute",
    top: -5,
    right: -8,
    backgroundColor: "#EF4444",
    borderRadius: 8,
    minWidth: 16,
    height: 16,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 3,
    borderWidth: 1.5,
    borderColor: colors.light.headerBg,
  },
  badgeText: {
    fontSize: 9,
    fontWeight: "800" as const,
    color: "#fff",
  },
  userBtn: {
    marginLeft: 6,
    marginBottom: 8,
  },
  userAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.35)",
  },
  menuCard: {
    position: "absolute",
    left: 12,
    backgroundColor: "#fff",
    borderRadius: 14,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.18,
    shadowRadius: 16,
    elevation: 12,
    overflow: "hidden",
    minWidth: 200,
  },
  menuHeader: {
    backgroundColor: colors.light.secondary,
    paddingHorizontal: 18,
    paddingVertical: 14,
    alignItems: "flex-end",
  },
  menuName: {
    fontSize: 17,
    fontWeight: "700" as const,
    color: colors.light.foreground,
    textAlign: "right",
    writingDirection: "rtl",
  },
  menuRole: {
    fontSize: 12,
    color: colors.light.mutedForeground,
    textAlign: "right",
    marginBottom: 2,
  },
  logoutRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
    gap: 10,
    paddingHorizontal: 18,
    paddingVertical: 14,
    borderTopWidth: 1,
    borderTopColor: colors.light.border,
  },
  logoutText: {
    fontSize: 15,
    fontWeight: "600" as const,
    color: colors.light.destructive,
  },
  alertBanner: {
    backgroundColor: "#F59E0B",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  alertText: {
    color: "#fff",
    fontSize: 13,
    fontWeight: "600" as const,
    textAlign: "right",
    flex: 1,
  },
});
