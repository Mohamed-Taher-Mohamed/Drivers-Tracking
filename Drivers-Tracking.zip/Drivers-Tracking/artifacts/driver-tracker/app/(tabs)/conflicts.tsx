import { Feather } from "@expo/vector-icons";
import React, { useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { Toast, useToast } from "@/components/Toast";
import colors from "@/constants/colors";
import { Conflict, Trip, useApp } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";
import { formatDatetime } from "@/utils/vehicleData";

function TripCard({ trip, selected, onSelect }: { trip: Trip; selected: boolean; onSelect: () => void }) {
  return (
    <TouchableOpacity
      style={[styles.tripCard, selected && styles.tripCardSelected]}
      onPress={onSelect}
      activeOpacity={0.8}
    >
      {selected && (
        <View style={styles.selectedBadge}>
          <Feather name="check" size={12} color="#fff" />
          <Text style={styles.selectedBadgeText}>صح</Text>
        </View>
      )}
      <Text style={styles.tripVehicle}>{trip.vehicle}</Text>
      <Text style={styles.tripDriver}>{trip.driverName}</Text>
      <Text style={styles.tripDetail}>{trip.shift}</Text>
      <Text style={styles.tripDetail}>{trip.station}</Text>
      <Text style={styles.tripTime}>من: {formatDatetime(trip.startDatetime)}</Text>
      {trip.endDatetime && <Text style={styles.tripTime}>إلى: {formatDatetime(trip.endDatetime)}</Text>}
    </TouchableOpacity>
  );
}

export default function ConflictsScreen() {
  const { conflicts, trips, resolveConflict } = useApp();
  const { currentUser } = useAuth();
  const insets = useSafeAreaInsets();
  const { state: toast, show: showToast, hide: hideToast } = useToast();

  const [resolvingId, setResolvingId] = useState<string | null>(null);
  const [selections, setSelections] = useState<Record<string, string>>({});

  const topPad = 0;
  const openConflicts = conflicts.filter((c) => !c.resolvedTripId);
  const resolvedConflicts = conflicts.filter((c) => !!c.resolvedTripId);

  const getTrip = (id: string): Trip | undefined => trips.find((t) => t.id === id);

  const handleResolve = async (conflict: Conflict) => {
    const chosen = selections[conflict.id];
    if (!chosen) { showToast("اختر الرحلة الصحيحة أولاً", "error"); return; }
    setResolvingId(conflict.id);
    try {
      await resolveConflict(conflict.id, chosen, currentUser?.username || "admin");
      showToast("تم حل التعارض", "success");
      setSelections((s) => { const n = { ...s }; delete n[conflict.id]; return n; });
    } finally {
      setResolvingId(null);
    }
  };

  const renderConflict = ({ item }: { item: Conflict }) => {
    const tripA = getTrip(item.tripAId);
    const tripB = getTrip(item.tripBId);
    const resolved = !!item.resolvedTripId;
    const chosen = selections[item.id];

    return (
      <View style={[styles.conflictCard, resolved && styles.conflictCardResolved]}>
        <View style={styles.conflictHeader}>
          <View style={[styles.conflictBadge, resolved && styles.conflictBadgeResolved]}>
            <Feather name={resolved ? "check-circle" : "alert-triangle"} size={14} color={resolved ? colors.light.success : colors.light.warning} />
            <Text style={[styles.conflictBadgeText, resolved && { color: colors.light.success }]}>
              {resolved ? "تم الحل" : "تعارض"}
            </Text>
          </View>
          <Text style={styles.conflictReason}>{item.reason}</Text>
        </View>

        {!resolved && (
          <Text style={styles.conflictHint}>اضغط على الرحلة الصحيحة لتحديدها</Text>
        )}

        <View style={styles.tripPair}>
          {tripA ? (
            <TripCard
              trip={tripA}
              selected={chosen === tripA.id}
              onSelect={() => !resolved && setSelections((s) => ({ ...s, [item.id]: tripA.id }))}
            />
          ) : (
            <View style={[styles.tripCard, styles.tripCardDeleted]}>
              <Text style={styles.tripDetail}>رحلة محذوفة</Text>
            </View>
          )}
          <View style={styles.vsCircle}><Text style={styles.vsText}>VS</Text></View>
          {tripB ? (
            <TripCard
              trip={tripB}
              selected={chosen === tripB.id}
              onSelect={() => !resolved && setSelections((s) => ({ ...s, [item.id]: tripB.id }))}
            />
          ) : (
            <View style={[styles.tripCard, styles.tripCardDeleted]}>
              <Text style={styles.tripDetail}>رحلة محذوفة</Text>
            </View>
          )}
        </View>

        {!resolved && (
          <TouchableOpacity
            style={[styles.resolveBtn, (!chosen || resolvingId === item.id) && styles.resolveBtnDisabled]}
            onPress={() => handleResolve(item)}
            disabled={!chosen || resolvingId === item.id}
            activeOpacity={0.8}
          >
            {resolvingId === item.id
              ? <ActivityIndicator color="#fff" size="small" />
              : (
                <>
                  <Feather name="check-square" size={16} color="#fff" />
                  <Text style={styles.resolveBtnText}>تأكيد الاختيار</Text>
                </>
              )
            }
          </TouchableOpacity>
        )}

        {resolved && (
          <View style={styles.resolvedInfo}>
            <Text style={styles.resolvedText}>
              تم الحل بواسطة: {item.resolvedBy} | {item.resolvedAt ? formatDatetime(item.resolvedAt) : ""}
            </Text>
          </View>
        )}
      </View>
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.light.background }}>
      <View style={[styles.header, { paddingTop: topPad + 12 }]}>
        <View style={styles.badge}>
          <Text style={styles.badgeText}>{openConflicts.length}</Text>
        </View>
        <Text style={styles.headerTitle}>أخطاء التسجيل</Text>
      </View>

      {conflicts.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Feather name="check-circle" size={56} color={colors.light.success} />
          <Text style={styles.emptyTitle}>لا توجد تعارضات</Text>
          <Text style={styles.emptySubtitle}>جميع البيانات متسقة</Text>
        </View>
      ) : (
        <FlatList
          data={[...openConflicts, ...resolvedConflicts]}
          keyExtractor={(item) => item.id}
          contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 120 }]}
          showsVerticalScrollIndicator={false}
          renderItem={renderConflict}
          ListHeaderComponent={openConflicts.length > 0 ? (
            <View style={styles.sectionHeader}>
              <Feather name="alert-triangle" size={14} color={colors.light.warning} />
              <Text style={styles.sectionHeaderText}>تعارضات مفتوحة ({openConflicts.length})</Text>
            </View>
          ) : null}
        />
      )}
      <Toast message={toast.message} type={toast.type} visible={toast.visible} onHide={hideToast} />
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    backgroundColor: colors.light.headerBg,
    paddingHorizontal: 20,
    paddingBottom: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  headerTitle: { fontSize: 22, fontWeight: "700" as const, color: "#fff" },
  badge: { backgroundColor: colors.light.warning, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, minWidth: 32, alignItems: "center" },
  badgeText: { color: "#fff", fontSize: 13, fontWeight: "700" as const },
  emptyContainer: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  emptyTitle: { fontSize: 18, fontWeight: "700" as const, color: colors.light.foreground },
  emptySubtitle: { fontSize: 14, color: colors.light.mutedForeground },
  list: { padding: 16, gap: 14 },
  sectionHeader: {
    flexDirection: "row", alignItems: "center", justifyContent: "flex-end",
    gap: 6, marginBottom: 8,
  },
  sectionHeaderText: { fontSize: 13, fontWeight: "600" as const, color: colors.light.warning },
  conflictCard: {
    backgroundColor: colors.light.card, borderRadius: colors.radius,
    padding: 14, borderWidth: 1.5, borderColor: "#FCD34D",
    shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 2,
  },
  conflictCardResolved: { borderColor: colors.light.border, opacity: 0.8 },
  conflictHeader: { flexDirection: "row", alignItems: "center", justifyContent: "flex-end", gap: 8, marginBottom: 10 },
  conflictBadge: {
    flexDirection: "row", alignItems: "center", gap: 4,
    backgroundColor: "#FEF9C3", paddingHorizontal: 8, paddingVertical: 4, borderRadius: 20,
  },
  conflictBadgeResolved: { backgroundColor: "#F0FFF4" },
  conflictBadgeText: { fontSize: 12, fontWeight: "700" as const, color: colors.light.warning },
  conflictReason: { fontSize: 14, fontWeight: "700" as const, color: colors.light.foreground, textAlign: "right", flex: 1 },
  conflictHint: { fontSize: 12, color: colors.light.mutedForeground, textAlign: "right", marginBottom: 10 },
  tripPair: { flexDirection: "row", gap: 8, alignItems: "center" },
  tripCard: {
    flex: 1, backgroundColor: colors.light.background, borderRadius: 10,
    padding: 10, borderWidth: 2, borderColor: "transparent",
  },
  tripCardSelected: { borderColor: colors.light.primary, backgroundColor: colors.light.secondary },
  tripCardDeleted: { opacity: 0.5 },
  selectedBadge: {
    flexDirection: "row", alignItems: "center", gap: 3,
    backgroundColor: colors.light.primary, borderRadius: 10,
    paddingHorizontal: 6, paddingVertical: 2, alignSelf: "flex-end", marginBottom: 6,
  },
  selectedBadgeText: { fontSize: 10, color: "#fff", fontWeight: "700" as const },
  tripVehicle: { fontSize: 16, fontWeight: "800" as const, color: colors.light.foreground, textAlign: "right" },
  tripDriver: { fontSize: 13, fontWeight: "600" as const, color: colors.light.foreground, textAlign: "right", marginTop: 2, writingDirection: "rtl" },
  tripDetail: { fontSize: 12, color: colors.light.mutedForeground, textAlign: "right", marginTop: 2, writingDirection: "rtl" },
  tripTime: { fontSize: 11, color: colors.light.mutedForeground, textAlign: "right", marginTop: 2, writingDirection: "rtl" },
  vsCircle: {
    width: 32, height: 32, borderRadius: 16,
    backgroundColor: colors.light.border, alignItems: "center", justifyContent: "center",
  },
  vsText: { fontSize: 10, fontWeight: "800" as const, color: colors.light.mutedForeground },
  resolveBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 8, backgroundColor: colors.light.primary, borderRadius: colors.radius,
    paddingVertical: 12, marginTop: 12,
  },
  resolveBtnDisabled: { opacity: 0.4 },
  resolveBtnText: { color: "#fff", fontSize: 14, fontWeight: "700" as const },
  resolvedInfo: { marginTop: 10, padding: 8, backgroundColor: "#F0FFF4", borderRadius: 8 },
  resolvedText: { fontSize: 12, color: colors.light.success, textAlign: "right" },
});
