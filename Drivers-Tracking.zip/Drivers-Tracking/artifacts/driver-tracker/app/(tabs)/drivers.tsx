import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Keyboard,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { Toast, useToast } from "@/components/Toast";
import colors from "@/constants/colors";
import { Driver, useApp } from "@/context/AppContext";
import { AppUser, useAuth } from "@/context/AuthContext";

type TabType = "drivers" | "users";

export default function DriversScreen() {
  const { drivers, addDriver, addDrivers, editDriver, deleteDriver, isLoading } = useApp();
  const { currentUser, users, addUser, deleteUser, logout } = useAuth();
  const insets = useSafeAreaInsets();
  const { state: toast, show: showToast, hide: hideToast } = useToast();

  const isAdmin = currentUser?.role === "admin";
  const [activeTab, setActiveTab] = useState<TabType>("drivers");
  const [submitting, setSubmitting] = useState(false);

  // Keyboard height tracking (works on web + native)
  const [kbHeight, setKbHeight] = useState(0);
  useEffect(() => {
    if (Platform.OS === "web") {
      const vv = (window as any).visualViewport as VisualViewport | undefined;
      if (!vv) return;
      const onResize = () => {
        const h = window.innerHeight - vv.height - vv.offsetTop;
        setKbHeight(Math.max(0, h));
      };
      vv.addEventListener("resize", onResize);
      return () => vv.removeEventListener("resize", onResize);
    } else {
      const show = Keyboard.addListener("keyboardDidShow", (e) => setKbHeight(e.endCoordinates.height));
      const hide = Keyboard.addListener("keyboardDidHide", () => setKbHeight(0));
      return () => { show.remove(); hide.remove(); };
    }
  }, []);

  // Bulk add state
  const [bulkVisible, setBulkVisible] = useState(false);
  const [bulkText, setBulkText] = useState("");
  const [bulkResult, setBulkResult] = useState<{ added: number; skipped: number } | null>(null);

  // Edit driver state
  const [editDriverVisible, setEditDriverVisible] = useState(false);
  const [editingDriver, setEditingDriver] = useState<Driver | null>(null);
  const [editName, setEditName] = useState("");
  const [editPhone, setEditPhone] = useState("");

  // Driver account modal state
  const [accountModalVisible, setAccountModalVisible] = useState(false);
  const [accountDriver, setAccountDriver] = useState<Driver | null>(null);
  const [acUsername, setAcUsername] = useState("");
  const [acPassword, setAcPassword] = useState("");
  const [acPasswordConfirm, setAcPasswordConfirm] = useState("");

  // Users tab
  const [addUserVisible, setAddUserVisible] = useState(false);
  const [newUsername, setNewUsername] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newRole, setNewRole] = useState<"admin" | "user">("user");
  const [addingUser, setAddingUser] = useState(false);

  const isPhoneLine = (line: string) => /^[\d\s\+\-\(\)]{6,}$/.test(line.trim());

  const parseBulkText = (text: string): { name: string; phone?: string }[] => {
    const lines = text.split("\n").map((l) => l.trim()).filter((l) => l.length > 0);
    const result: { name: string; phone?: string }[] = [];
    let i = 0;
    while (i < lines.length) {
      const line = lines[i]!;
      if (isPhoneLine(line)) { i++; continue; }
      const name = line;
      let phone: string | undefined;
      if (i + 1 < lines.length && isPhoneLine(lines[i + 1]!)) {
        phone = lines[i + 1];
        i += 2;
      } else {
        i++;
      }
      result.push({ name, phone });
    }
    return result;
  };

  const handleBulkAdd = async () => {
    const parsed = parseBulkText(bulkText);
    if (parsed.length === 0) { showToast("يرجى كتابة أسماء السائقين أولاً", "error"); return; }
    setSubmitting(true);
    setBulkResult(null);
    try {
      // استخدام addDrivers مرة واحدة لتجنب مشكلة القراءة القديمة للـ state
      const { added, skipped } = await addDrivers(parsed);
      setBulkResult({ added, skipped });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      showToast(`تم إضافة ${added} سائق${skipped > 0 ? ` (${skipped} مكرر)` : ""}`, added > 0 ? "success" : "error");
      if (added > 0) {
        setBulkText("");
        setBulkVisible(false);
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleOpenEdit = (driver: Driver) => {
    setEditingDriver(driver);
    setEditName(driver.name);
    setEditPhone(driver.phone || "");
    setEditDriverVisible(true);
  };

  const handleOpenAccountModal = (driver: Driver) => {
    const linked = users.find((u) => u.linkedDriverName === driver.name);
    setAccountDriver(driver);
    setAcUsername(linked ? linked.username : driver.name);
    setAcPassword("");
    setAcPasswordConfirm("");
    setAccountModalVisible(true);
  };

  const handleSaveAccount = () => {
    if (!accountDriver) return;
    const linked = users.find((u) => u.linkedDriverName === accountDriver.name);
    if (!acUsername.trim()) { showToast("يرجى إدخال اسم المستخدم", "error"); return; }
    if (!acPassword) { showToast("يرجى إدخال كلمة المرور", "error"); return; }
    if (acPassword !== acPasswordConfirm) { showToast("كلمة المرور غير متطابقة", "error"); return; }

    const action = linked ? "تعديل" : "إنشاء";
    Alert.alert(
      `تأكيد ${action} الحساب`,
      linked
        ? `هل تريد تعديل حساب السائق "${accountDriver.name}" باسم المستخدم "${acUsername.trim()}"؟`
        : `هل تريد إنشاء حساب دخول للسائق "${accountDriver.name}" باسم المستخدم "${acUsername.trim()}"؟`,
      [
        { text: "إلغاء", style: "cancel" },
        {
          text: `نعم، ${action}`, style: "default",
          onPress: async () => {
            setSubmitting(true);
            try {
              if (linked) {
                await deleteUser(linked.id);
                const result = await addUser(acUsername.trim(), acPassword, "driver", accountDriver.name);
                if (result.ok) { showToast("تم تعديل حساب السائق", "success"); setAccountModalVisible(false); }
                else showToast(result.message, "error");
              } else {
                const result = await addUser(acUsername.trim(), acPassword, "driver", accountDriver.name);
                if (result.ok) { showToast("تم إنشاء حساب السائق", "success"); setAccountModalVisible(false); }
                else showToast(result.message, "error");
              }
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            } finally {
              setSubmitting(false);
            }
          },
        },
      ]
    );
  };

  const handleDeleteAccount = (driver: Driver) => {
    const linked = users.find((u) => u.linkedDriverName === driver.name);
    if (!linked) return;
    Alert.alert("حذف الحساب", `هل تريد حذف حساب "${linked.username}"؟`, [
      { text: "إلغاء", style: "cancel" },
      { text: "حذف", style: "destructive", onPress: async () => { await deleteUser(linked.id); showToast("تم حذف الحساب", "info"); setAccountModalVisible(false); } },
    ]);
  };

  const handleEditDriver = () => {
    if (!editingDriver) return;
    Alert.alert(
      "تأكيد تعديل البيانات",
      `هل تريد حفظ التعديلات على السائق "${editingDriver.name}"؟`,
      [
        { text: "إلغاء", style: "cancel" },
        {
          text: "نعم، احفظ", style: "default",
          onPress: async () => {
            setSubmitting(true);
            try {
              await editDriver(editingDriver.id, editName, editPhone);
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              showToast("تم تعديل بيانات السائق", "success");
              setEditDriverVisible(false);
              setEditingDriver(null);
            } finally {
              setSubmitting(false);
            }
          },
        },
      ]
    );
  };

  const handleDeleteDriver = (id: string, name: string) => {
    Alert.alert(
      "تأكيد حذف السائق",
      `هل أنت متأكد من حذف السائق "${name}"؟\n\nسيتم حذف بياناته نهائياً ولا يمكن التراجع عن هذا الإجراء.`,
      [
        { text: "إلغاء", style: "cancel" },
        {
          text: "نعم، احذف", style: "destructive",
          onPress: async () => { await deleteDriver(id); showToast(`تم حذف ${name}`, "info"); },
        },
      ],
      { cancelable: true }
    );
  };

  const handleAddUser = async () => {
    if (!newUsername.trim() || !newPassword) { showToast("اسم المستخدم وكلمة المرور مطلوبان", "error"); return; }
    setAddingUser(true);
    try {
      const result = await addUser(newUsername.trim(), newPassword, newRole);
      if (result.ok) {
        showToast("تم إضافة المستخدم", "success");
        setNewUsername(""); setNewPassword(""); setNewRole("user");
        setAddUserVisible(false);
      } else {
        showToast(result.message, "error");
      }
    } finally {
      setAddingUser(false);
    }
  };

  const handleDeleteUser = (user: AppUser) => {
    if (user.username === "admin") { showToast("لا يمكن حذف حساب admin", "error"); return; }
    Alert.alert("حذف المستخدم", `هل تريد حذف "${user.username}"؟`, [
      { text: "إلغاء", style: "cancel" },
      {
        text: "حذف", style: "destructive",
        onPress: async () => { await deleteUser(user.id); showToast("تم حذف المستخدم", "info"); },
      },
    ]);
  };

  const handleLogout = () => {
    Alert.alert("تسجيل الخروج", "هل تريد تسجيل الخروج؟", [
      { text: "إلغاء", style: "cancel" },
      { text: "خروج", style: "destructive", onPress: () => logout() },
    ]);
  };

  const roleLabel = (role: string) => {
    if (role === "admin") return "أدمن";
    if (role === "driver") return "سائق";
    return "مستخدم";
  };
  const roleBadgeColor = (role: string) => {
    if (role === "admin") return { bg: "#EDE9FE", text: "#7C3AED" };
    if (role === "driver") return { bg: "#DCFCE7", text: "#16A34A" };
    return { bg: colors.light.muted, text: colors.light.mutedForeground };
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: colors.light.background }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <View style={[styles.header]}>
        <TouchableOpacity onPress={handleLogout} style={styles.logoutBtn}>
          <Feather name="log-out" size={18} color="rgba(255,255,255,0.85)" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>الإدارة</Text>
      </View>

      {isAdmin && (
        <View style={styles.tabSwitcher}>
          <TouchableOpacity style={[styles.tabSwitch, activeTab === "users" && styles.tabSwitchActive]} onPress={() => setActiveTab("users")}>
            <Feather name="users" size={15} color={activeTab === "users" ? "#fff" : colors.light.mutedForeground} />
            <Text style={[styles.tabSwitchText, activeTab === "users" && styles.tabSwitchTextActive]}>المستخدمون</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.tabSwitch, activeTab === "drivers" && styles.tabSwitchActive]} onPress={() => setActiveTab("drivers")}>
            <Feather name="truck" size={15} color={activeTab === "drivers" ? "#fff" : colors.light.mutedForeground} />
            <Text style={[styles.tabSwitchText, activeTab === "drivers" && styles.tabSwitchTextActive]}>السائقون</Text>
          </TouchableOpacity>
        </View>
      )}

      {activeTab === "drivers" ? (
        <>
          <View style={styles.listHeader}>
            <TouchableOpacity style={styles.addDriverBtn} onPress={() => { setBulkResult(null); setBulkVisible(true); }}>
              <Feather name="user-plus" size={16} color="#fff" />
              <Text style={styles.addDriverBtnText}>إضافة سائقين</Text>
            </TouchableOpacity>
            <Text style={styles.listHeaderTitle}>السائقون ({drivers.length})</Text>
          </View>

          {isLoading ? (
            <ActivityIndicator color={colors.light.primary} style={{ marginTop: 32 }} />
          ) : drivers.length === 0 ? (
            <View style={styles.emptyContainer}>
              <Feather name="users" size={48} color={colors.light.border} />
              <Text style={styles.emptyTitle}>لا يوجد سائقون</Text>
              <Text style={styles.emptySubtitle}>اضغط "إضافة سائقين" للبدء</Text>
            </View>
          ) : (
            <FlatList
              data={drivers}
              keyExtractor={(item) => item.id}
              contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 120 }]}
              showsVerticalScrollIndicator={false}
              renderItem={({ item, index }) => {
                const linkedAccount = users.find((u) => u.linkedDriverName === item.name);
                return (
                  <View style={styles.driverCard}>
                    {/* معلومات السائق - كامل العرض */}
                    <View style={styles.driverCardInfo}>
                      <View style={styles.driverCardTop}>
                        <Text style={styles.driverIndex}>#{index + 1}</Text>
                        <View style={styles.driverNameRow}>
                          {linkedAccount && (
                            <View style={styles.accountBadge}>
                              <Feather name="user-check" size={10} color={colors.light.success} />
                              <Text style={styles.accountBadgeText}>حساب</Text>
                            </View>
                          )}
                          <Text style={styles.driverName}>{item.name}</Text>
                        </View>
                      </View>
                      {item.phone ? (
                        <View style={styles.phoneRow}>
                          <Text style={styles.driverPhone}>{item.phone}</Text>
                          <Feather name="phone" size={11} color={colors.light.success} />
                        </View>
                      ) : (
                        <Text style={styles.noPhone}>لا يوجد رقم تليفون</Text>
                      )}
                    </View>

                    {/* فاصل */}
                    <View style={styles.driverCardDivider} />

                    {/* أزرار الإجراءات - صف بنص */}
                    <View style={styles.driverCardActions}>
                      <TouchableOpacity
                        style={[styles.cardBtn, linkedAccount ? styles.cardBtnAccountActive : styles.cardBtnAccount]}
                        onPress={() => handleOpenAccountModal(item)}
                        activeOpacity={0.75}
                      >
                        <Feather name={linkedAccount ? "user-check" : "user-plus"} size={13} color={linkedAccount ? colors.light.success : colors.light.mutedForeground} />
                        <Text style={[styles.cardBtnText, linkedAccount ? styles.cardBtnTextAccountActive : styles.cardBtnTextAccount]}>
                          {linkedAccount ? "تعديل حساب" : "إنشاء حساب"}
                        </Text>
                      </TouchableOpacity>

                      <TouchableOpacity
                        style={[styles.cardBtn, styles.cardBtnEdit]}
                        onPress={() => handleOpenEdit(item)}
                        activeOpacity={0.75}
                      >
                        <Feather name="edit-2" size={13} color={colors.light.primary} />
                        <Text style={[styles.cardBtnText, styles.cardBtnTextEdit]}>تعديل</Text>
                      </TouchableOpacity>

                      <TouchableOpacity
                        style={[styles.cardBtn, styles.cardBtnDelete]}
                        onPress={() => handleDeleteDriver(item.id, item.name)}
                        activeOpacity={0.75}
                      >
                        <Feather name="trash-2" size={13} color={colors.light.destructive} />
                        <Text style={[styles.cardBtnText, styles.cardBtnTextDelete]}>حذف</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                );
              }}
            />
          )}
        </>
      ) : (
        <>
          <View style={styles.listHeader}>
            <TouchableOpacity style={styles.addDriverBtn} onPress={() => setAddUserVisible(true)}>
              <Feather name="user-plus" size={16} color="#fff" />
              <Text style={styles.addDriverBtnText}>إضافة مستخدم</Text>
            </TouchableOpacity>
            <Text style={styles.listHeaderTitle}>المستخدمون ({users.length})</Text>
          </View>

          <FlatList
            data={users}
            keyExtractor={(u) => u.id}
            contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 120 }]}
            showsVerticalScrollIndicator={false}
            renderItem={({ item }) => {
              const rc = roleBadgeColor(item.role);
              return (
                <View style={styles.userRow}>
                  {item.username !== "admin" && (
                    <TouchableOpacity style={styles.deleteBtn} onPress={() => handleDeleteUser(item)}>
                      <Feather name="trash-2" size={15} color={colors.light.destructive} />
                    </TouchableOpacity>
                  )}
                  <View style={styles.driverInfo}>
                    <View style={styles.userNameRow}>
                      <View style={[styles.roleBadge, { backgroundColor: rc.bg }]}>
                        <Text style={[styles.roleText, { color: rc.text }]}>{roleLabel(item.role)}</Text>
                      </View>
                      <Text style={styles.driverName}>{item.username}</Text>
                    </View>
                    {item.linkedDriverName && (
                      <Text style={styles.linkedDriver}>مرتبط بـ: {item.linkedDriverName}</Text>
                    )}
                    {item.id === currentUser?.id && (
                      <Text style={styles.currentUserLabel}>أنت</Text>
                    )}
                  </View>
                </View>
              );
            }}
          />
        </>
      )}

      {/* Modal إضافة سواقين */}
      <Modal visible={bulkVisible} transparent animationType="slide" onRequestClose={() => { setBulkVisible(false); Keyboard.dismiss(); }}>
        <View style={styles.modalOverlay}>
          <View style={[styles.bulkModalSheet, { marginBottom: kbHeight }]}>
            <View style={styles.modalHandle} />
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => { setBulkVisible(false); Keyboard.dismiss(); }}>
                <Feather name="x" size={22} color={colors.light.foreground} />
              </TouchableOpacity>
              <Text style={styles.modalTitle}>إضافة سائقين</Text>
            </View>

            <ScrollView
              contentContainerStyle={styles.bulkContent}
              keyboardShouldPersistTaps="handled"
              showsVerticalScrollIndicator={false}
            >
              <View style={styles.bulkHintBox}>
                <Text style={styles.bulkHintTitle}>طريقة الكتابة:</Text>
                <Text style={styles.bulkHintText}>{"محمد أحمد\n01012345678\nعلي حسن\n01098765432"}</Text>
              </View>

              <TextInput
                style={styles.bulkTextArea}
                value={bulkText}
                onChangeText={setBulkText}
                placeholder={"اكتب اسم السائق\nثم رقم تليفونه تحته\nثم الاسم التالي\nوهكذا..."}
                placeholderTextColor={colors.light.mutedForeground}
                multiline
                textAlign="right"
                textAlignVertical="top"
                scrollEnabled={false}
              />

              {bulkResult && bulkResult.skipped > 0 && (
                <View style={styles.bulkResultBox}>
                  <Text style={styles.bulkResultText}>
                    تمت الإضافة: {bulkResult.added} ✓  —  مكرر: {bulkResult.skipped}
                  </Text>
                </View>
              )}

              <TouchableOpacity
                style={[styles.addBtn, (submitting || !bulkText.trim()) && styles.addBtnDisabled]}
                onPress={handleBulkAdd}
                disabled={submitting || !bulkText.trim()}
                activeOpacity={0.8}
              >
                {submitting ? <ActivityIndicator color="#fff" size="small" /> : (
                  <>
                    <Feather name="user-plus" size={18} color="#fff" />
                    <Text style={styles.addBtnText}>إضافة الكل</Text>
                  </>
                )}
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Modal تعديل سائق */}
      <Modal visible={editDriverVisible} transparent animationType="slide" onRequestClose={() => setEditDriverVisible(false)}>
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
          <View style={styles.modalOverlay}>
            <View style={[styles.bulkModal, { paddingBottom: insets.bottom + 16 }]}>
              <View style={styles.modalHandle} />
              <View style={styles.modalHeader}>
                <TouchableOpacity onPress={() => setEditDriverVisible(false)}>
                  <Feather name="x" size={22} color={colors.light.foreground} />
                </TouchableOpacity>
                <Text style={styles.modalTitle}>تعديل بيانات السائق</Text>
              </View>
              <ScrollView contentContainerStyle={styles.bulkContent} keyboardShouldPersistTaps="handled">
                <Text style={styles.fieldLabel}>اسم السائق</Text>
                <TextInput
                  style={styles.modalInputFull}
                  value={editName}
                  onChangeText={setEditName}
                  placeholder="اسم السائق"
                  placeholderTextColor={colors.light.mutedForeground}
                  textAlign="right"
                />
                <Text style={styles.fieldLabel}>رقم التليفون</Text>
                <TextInput
                  style={styles.modalInputFull}
                  value={editPhone}
                  onChangeText={setEditPhone}
                  placeholder="مثال: 01012345678"
                  placeholderTextColor={colors.light.mutedForeground}
                  textAlign="right"
                  keyboardType="phone-pad"
                />

                <TouchableOpacity
                  style={[styles.addBtn, (submitting || !editName.trim()) && styles.addBtnDisabled]}
                  onPress={handleEditDriver}
                  disabled={submitting || !editName.trim()}
                  activeOpacity={0.8}
                >
                  {submitting ? <ActivityIndicator color="#fff" size="small" /> : (
                    <>
                      <Feather name="save" size={18} color="#fff" />
                      <Text style={styles.addBtnText}>حفظ التعديلات</Text>
                    </>
                  )}
                </TouchableOpacity>
              </ScrollView>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* Modal حساب السائق (إنشاء / تعديل) */}
      <Modal visible={accountModalVisible} transparent animationType="slide" onRequestClose={() => setAccountModalVisible(false)}>
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
          <View style={styles.modalOverlay}>
            <View style={[styles.bulkModal, { paddingBottom: insets.bottom + 16 }]}>
              <View style={styles.modalHandle} />
              <View style={styles.modalHeader}>
                <TouchableOpacity onPress={() => setAccountModalVisible(false)}>
                  <Feather name="x" size={22} color={colors.light.foreground} />
                </TouchableOpacity>
                <Text style={styles.modalTitle}>
                  {users.some((u) => u.linkedDriverName === accountDriver?.name) ? "تعديل حساب السائق" : "إنشاء حساب للسائق"}
                </Text>
              </View>

              <ScrollView contentContainerStyle={styles.bulkContent} keyboardShouldPersistTaps="handled">
                {/* اسم السائق */}
                <View style={styles.acDriverNameBox}>
                  <Feather name="user" size={14} color={colors.light.primary} />
                  <Text style={styles.acDriverName}>{accountDriver?.name}</Text>
                </View>

                {/* إذا كان عنده حساب سابق */}
                {users.some((u) => u.linkedDriverName === accountDriver?.name) && (
                  <View style={styles.acExistingBadge}>
                    <Feather name="user-check" size={13} color={colors.light.success} />
                    <Text style={styles.acExistingText}>
                      حساب موجود: {users.find((u) => u.linkedDriverName === accountDriver?.name)?.username}
                    </Text>
                  </View>
                )}

                <Text style={styles.fieldLabel}>اسم المستخدم (للدخول)</Text>
                <TextInput
                  style={styles.modalInputFull}
                  value={acUsername}
                  onChangeText={setAcUsername}
                  placeholder="اسم الدخول"
                  placeholderTextColor={colors.light.mutedForeground}
                  textAlign="right"
                  autoCapitalize="none"
                />
                <Text style={styles.fieldLabel}>كلمة المرور</Text>
                <TextInput
                  style={styles.modalInputFull}
                  value={acPassword}
                  onChangeText={setAcPassword}
                  placeholder="كلمة مرور جديدة"
                  placeholderTextColor={colors.light.mutedForeground}
                  textAlign="right"
                  secureTextEntry
                />
                <Text style={styles.fieldLabel}>تأكيد كلمة المرور</Text>
                <TextInput
                  style={styles.modalInputFull}
                  value={acPasswordConfirm}
                  onChangeText={setAcPasswordConfirm}
                  placeholder="أعد كتابة كلمة المرور"
                  placeholderTextColor={colors.light.mutedForeground}
                  textAlign="right"
                  secureTextEntry
                />

                <TouchableOpacity
                  style={[styles.addBtn, (submitting || !acUsername.trim() || !acPassword) && styles.addBtnDisabled]}
                  onPress={handleSaveAccount}
                  disabled={submitting || !acUsername.trim() || !acPassword}
                  activeOpacity={0.8}
                >
                  {submitting ? <ActivityIndicator color="#fff" size="small" /> : (
                    <>
                      <Feather name="save" size={18} color="#fff" />
                      <Text style={styles.addBtnText}>
                        {users.some((u) => u.linkedDriverName === accountDriver?.name) ? "تعديل الحساب" : "إنشاء الحساب"}
                      </Text>
                    </>
                  )}
                </TouchableOpacity>

                {users.some((u) => u.linkedDriverName === accountDriver?.name) && (
                  <TouchableOpacity style={styles.deleteAccountBtn} onPress={() => accountDriver && handleDeleteAccount(accountDriver)} activeOpacity={0.8}>
                    <Feather name="trash-2" size={15} color={colors.light.destructive} />
                    <Text style={styles.deleteAccountBtnText}>حذف الحساب</Text>
                  </TouchableOpacity>
                )}
              </ScrollView>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* Modal إضافة مستخدم */}
      <Modal visible={addUserVisible} transparent animationType="slide" onRequestClose={() => setAddUserVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={[styles.bulkModal, { paddingBottom: insets.bottom + 16 }]}>
            <View style={styles.modalHandle} />
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => setAddUserVisible(false)}>
                <Feather name="x" size={22} color={colors.light.foreground} />
              </TouchableOpacity>
              <Text style={styles.modalTitle}>إضافة مستخدم جديد</Text>
            </View>
            <View style={styles.bulkContent}>
              <Text style={styles.fieldLabel}>اسم المستخدم</Text>
              <TextInput style={styles.modalInputFull} value={newUsername} onChangeText={setNewUsername} placeholder="أدخل اسم المستخدم" placeholderTextColor={colors.light.mutedForeground} autoCapitalize="none" textAlign="right" />
              <Text style={styles.fieldLabel}>كلمة المرور</Text>
              <TextInput style={styles.modalInputFull} value={newPassword} onChangeText={setNewPassword} placeholder="أدخل كلمة المرور" placeholderTextColor={colors.light.mutedForeground} secureTextEntry textAlign="right" />
              <Text style={styles.fieldLabel}>الصلاحية</Text>
              <View style={styles.roleSelector}>
                {(["user", "admin"] as const).map((r) => (
                  <TouchableOpacity key={r} style={[styles.roleOption, newRole === r && styles.roleOptionActive]} onPress={() => setNewRole(r)}>
                    <Text style={[styles.roleOptionText, newRole === r && styles.roleOptionTextActive]}>{r === "admin" ? "أدمن" : "مستخدم"}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              <TouchableOpacity style={[styles.addBtn, addingUser && { opacity: 0.6 }]} onPress={handleAddUser} disabled={addingUser} activeOpacity={0.8}>
                {addingUser ? <ActivityIndicator color="#fff" size="small" /> : <Text style={styles.addBtnText}>إضافة</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Toast message={toast.message} type={toast.type} visible={toast.visible} onHide={hideToast} />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  header: {
    backgroundColor: colors.light.headerBg, paddingHorizontal: 20, paddingBottom: 16, paddingTop: 12,
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
  },
  headerTitle: { fontSize: 22, fontWeight: "700" as const, color: "#fff" },
  logoutBtn: { padding: 6 },
  tabSwitcher: {
    flexDirection: "row", margin: 16, backgroundColor: colors.light.muted,
    borderRadius: 14, padding: 4, gap: 4,
  },
  tabSwitch: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingVertical: 9, borderRadius: 10 },
  tabSwitchActive: { backgroundColor: colors.light.primary },
  tabSwitchText: { fontSize: 14, fontWeight: "600" as const, color: colors.light.mutedForeground },
  tabSwitchTextActive: { color: "#fff" },
  listHeader: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 16, paddingVertical: 10,
  },
  listHeaderTitle: { fontSize: 16, fontWeight: "700" as const, color: colors.light.foreground },
  addDriverBtn: {
    flexDirection: "row", alignItems: "center", gap: 6,
    backgroundColor: colors.light.primary, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 10,
  },
  addDriverBtnText: { color: "#fff", fontSize: 14, fontWeight: "700" as const },
  emptyContainer: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  emptyTitle: { fontSize: 18, fontWeight: "700" as const, color: colors.light.foreground },
  emptySubtitle: { fontSize: 14, color: colors.light.mutedForeground },
  list: { paddingHorizontal: 16, gap: 6 },
  driverRow: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    backgroundColor: colors.light.card, paddingHorizontal: 14, paddingVertical: 12,
    borderRadius: 10, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.04, shadowRadius: 2, elevation: 1,
  },
  driverCard: {
    backgroundColor: colors.light.card, borderRadius: 12,
    shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 3, elevation: 2,
    overflow: "hidden",
  },
  driverCardInfo: { paddingHorizontal: 14, paddingTop: 12, paddingBottom: 10, alignItems: "flex-end" },
  driverCardTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", width: "100%" },
  driverCardDivider: { height: 1, backgroundColor: colors.light.border },
  driverCardActions: { flexDirection: "row", alignItems: "center" },
  cardBtn: {
    flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 5, paddingVertical: 10,
  },
  cardBtnText: { fontSize: 12, fontWeight: "600" as const },
  cardBtnAccount: { borderRightWidth: 1, borderRightColor: colors.light.border },
  cardBtnAccountActive: { borderRightWidth: 1, borderRightColor: colors.light.border },
  cardBtnEdit: { borderRightWidth: 1, borderRightColor: colors.light.border },
  cardBtnDelete: {},
  cardBtnTextAccount: { color: colors.light.mutedForeground },
  cardBtnTextAccountActive: { color: colors.light.success },
  cardBtnTextEdit: { color: colors.light.primary },
  cardBtnTextDelete: { color: colors.light.destructive },
  userRow: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    backgroundColor: colors.light.card, paddingHorizontal: 14, paddingVertical: 12,
    borderRadius: 10, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.03, shadowRadius: 2, elevation: 1,
  },
  driverInfo: { alignItems: "flex-end", flex: 1 },
  driverNameRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  driverName: { fontSize: 15, fontWeight: "600" as const, color: colors.light.foreground, writingDirection: "rtl" },
  accountBadge: {
    flexDirection: "row", alignItems: "center", gap: 3,
    backgroundColor: "#DCFCE7", paddingHorizontal: 6, paddingVertical: 2, borderRadius: 10,
  },
  accountBadgeText: { fontSize: 10, color: colors.light.success, fontWeight: "700" as const },
  phoneRow: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 2 },
  driverPhone: { fontSize: 12, color: colors.light.success, fontWeight: "500" as const },
  noPhone: { fontSize: 11, color: colors.light.mutedForeground, marginTop: 2, fontStyle: "italic" },
  driverIndex: { fontSize: 11, color: colors.light.mutedForeground, marginTop: 2 },
  driverActions: { flexDirection: "row", gap: 6, alignItems: "center" },
  editBtn: {
    padding: 8, backgroundColor: colors.light.secondary, borderRadius: 8,
    borderWidth: 1, borderColor: colors.light.primary + "40",
  },
  deleteBtn: { padding: 8 },
  userNameRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  linkedDriver: { fontSize: 11, color: colors.light.primary, marginTop: 2 },
  roleBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 20 },
  roleText: { fontSize: 11, fontWeight: "700" as const },
  currentUserLabel: { fontSize: 11, color: colors.light.success, fontWeight: "600" as const, marginTop: 2 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" },
  bulkModal: { backgroundColor: colors.light.card, borderTopLeftRadius: 24, borderTopRightRadius: 24 },
  bulkModalSheet: {
    backgroundColor: colors.light.card,
    borderTopLeftRadius: 24, borderTopRightRadius: 24,
    maxHeight: "90%",
    paddingBottom: 16,
  },
  modalHandle: { width: 40, height: 4, backgroundColor: colors.light.border, borderRadius: 2, alignSelf: "center", marginTop: 10 },
  modalHeader: {
    flexDirection: "row", alignItems: "center", justifyContent: "flex-end",
    paddingHorizontal: 20, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: colors.light.border, gap: 8,
  },
  modalTitle: { flex: 1, fontSize: 17, fontWeight: "700" as const, color: colors.light.foreground, textAlign: "right" },
  bulkContent: { padding: 16, gap: 10 },
  bulkHintBox: {
    backgroundColor: colors.light.secondary, borderRadius: 10, padding: 12,
    borderWidth: 1, borderColor: colors.light.primary + "30",
  },
  bulkHintTitle: { fontSize: 13, fontWeight: "700" as const, color: colors.light.primary, textAlign: "right", marginBottom: 4 },
  bulkHintText: { fontSize: 12, color: colors.light.mutedForeground, textAlign: "right", lineHeight: 20 },
  bulkTextArea: {
    backgroundColor: colors.light.background, borderWidth: 1.5, borderColor: colors.light.border,
    borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12,
    fontSize: 15, color: colors.light.foreground,
    minHeight: 200, textAlignVertical: "top",
    lineHeight: 26,
  },
  bulkResultBox: {
    backgroundColor: "#FEF3C7", borderRadius: 8, padding: 10, alignItems: "center",
  },
  bulkResultText: { fontSize: 13, color: "#92400E", fontWeight: "600" as const, textAlign: "center" },
  fieldLabel: { fontSize: 14, fontWeight: "600" as const, color: colors.light.foreground, textAlign: "right", marginTop: 4 },
  modalInputFull: {
    backgroundColor: colors.light.background, borderWidth: 1.5, borderColor: colors.light.border,
    borderRadius: colors.radius, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15, color: colors.light.foreground,
    marginTop: 4,
  },
  divider: { height: 1, backgroundColor: colors.light.border, marginVertical: 8 },
  createAccountToggle: {
    flexDirection: "row", alignItems: "center", justifyContent: "flex-end",
    gap: 10, paddingVertical: 6,
  },
  createAccountText: { fontSize: 14, fontWeight: "600" as const, color: colors.light.primary },
  accountSection: {
    backgroundColor: colors.light.secondary, borderRadius: 10, padding: 12, gap: 4,
  },
  accountSectionLabel: { fontSize: 12, color: colors.light.mutedForeground, textAlign: "right", marginBottom: 4 },
  hasAccountBox: {
    flexDirection: "row", alignItems: "center", justifyContent: "flex-end",
    gap: 6, backgroundColor: "#DCFCE7", borderRadius: 8, padding: 10, marginTop: 4,
  },
  hasAccountText: { fontSize: 13, color: colors.light.success, fontWeight: "600" as const },
  addBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8,
    backgroundColor: colors.light.primary, borderRadius: colors.radius, paddingVertical: 14, marginTop: 12,
  },
  addBtnDisabled: { opacity: 0.5 },
  addBtnText: { color: "#fff", fontSize: 15, fontWeight: "700" as const },
  accountBtnActive: {
    borderColor: colors.light.success + "60",
    backgroundColor: "#DCFCE7",
  },
  accountBtnInactive: {
    borderColor: colors.light.border,
    backgroundColor: colors.light.secondary,
  },
  acDriverNameBox: {
    flexDirection: "row", alignItems: "center", justifyContent: "flex-end",
    gap: 6, backgroundColor: colors.light.secondary,
    borderRadius: 10, padding: 12,
  },
  acDriverName: { fontSize: 16, fontWeight: "700" as const, color: colors.light.foreground },
  acExistingBadge: {
    flexDirection: "row", alignItems: "center", justifyContent: "flex-end",
    gap: 6, backgroundColor: "#DCFCE7", borderRadius: 8, padding: 10,
  },
  acExistingText: { fontSize: 13, color: colors.light.success, fontWeight: "600" as const },
  deleteAccountBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8,
    borderWidth: 1.5, borderColor: colors.light.destructive + "60",
    borderRadius: colors.radius, paddingVertical: 12, marginTop: 4,
  },
  deleteAccountBtnText: { color: colors.light.destructive, fontSize: 14, fontWeight: "600" as const },
  roleSelector: { flexDirection: "row", gap: 10, marginTop: 4 },
  roleOption: {
    flex: 1, paddingVertical: 11, borderRadius: 10,
    borderWidth: 1.5, borderColor: colors.light.border, alignItems: "center",
  },
  roleOptionActive: { borderColor: colors.light.primary, backgroundColor: colors.light.secondary },
  roleOptionText: { fontSize: 14, fontWeight: "600" as const, color: colors.light.mutedForeground },
  roleOptionTextActive: { color: colors.light.primary },
});
