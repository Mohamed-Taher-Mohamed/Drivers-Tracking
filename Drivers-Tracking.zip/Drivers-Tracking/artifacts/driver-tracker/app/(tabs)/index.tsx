import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { CustomPicker } from "@/components/CustomPicker";
import { TripEditModal } from "@/components/TripEditModal";
import { Toast, useToast } from "@/components/Toast";
import colors from "@/constants/colors";
import { Trip, useApp } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";
import { SHIFTS, STATIONS, VEHICLE_TYPES, getVehicleOptions } from "@/utils/vehicleData";

export default function StartTripScreen() {
  const { drivers, activeTrips, myActiveTrips, startTrip, editTrip, handoffDriver, isLoading, isSyncing, syncNow, canEdit } = useApp();
  const { currentUser } = useAuth();
  const insets = useSafeAreaInsets();
  const { state: toast, show: showToast, hide: hideToast } = useToast();

  const isAdmin = currentUser?.role === "admin";
  const isDriver = currentUser?.role === "driver";
  const linkedDriverName = currentUser?.linkedDriverName || "";

  const [vehicleType, setVehicleType] = useState("");
  const [vehicle, setVehicle] = useState("");
  const [shift, setShift] = useState("");
  const [station, setStation] = useState("");
  const [fromStation, setFromStation] = useState("");
  const [toStation, setToStation] = useState("");
  const [driverName, setDriverName] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [editingTrip, setEditingTrip] = useState<Trip | null>(null);

  const [handoffTrip, setHandoffTrip] = useState<Trip | null>(null);
  const [handoffDriver_, setHandoffDriver_] = useState("");
  const [handoffSubmitting, setHandoffSubmitting] = useState(false);

  useEffect(() => {
    if (isDriver && linkedDriverName) setDriverName(linkedDriverName);
  }, [isDriver, linkedDriverName]);

  const vehicleOptions = vehicleType ? getVehicleOptions(vehicleType) : [];
  const driverOptions = drivers.map((d) => ({ label: d.name, value: d.name }));
  const isGhiab = shift === "الذهاب إلى محطة";

  const displayedActiveTrips = isAdmin ? activeTrips : myActiveTrips;

  const handleVehicleTypeSelect = (type: string) => { setVehicleType(type); setVehicle(""); };

  const handleSubmit = async () => {
    if (!vehicleType) { showToast("يرجى اختيار نوع المركبة", "error"); return; }
    if (!vehicle) { showToast("يرجى اختيار رقم المركبة", "error"); return; }
    if (!shift) { showToast("يرجى اختيار الوردية", "error"); return; }
    if (isGhiab) {
      if (!fromStation) { showToast("يرجى اختيار محطة المغادرة", "error"); return; }
      if (!toStation) { showToast("يرجى اختيار محطة الوصول", "error"); return; }
    } else {
      if (!station) { showToast("يرجى اختيار المحطة", "error"); return; }
    }
    if (!driverName) { showToast("يرجى اختيار السائق", "error"); return; }

    const vehicleAlreadyActive = activeTrips.find((t) => t.vehicle === vehicle);
    if (vehicleAlreadyActive) { showToast(`المركبة ${vehicle} لديها رحلة مفتوحة`, "error"); return; }
    const driverAlreadyActive = activeTrips.find((t) => t.driverName === driverName);
    if (driverAlreadyActive) { showToast(`السائق ${driverName} على ${driverAlreadyActive.vehicle} حالياً`, "error"); return; }

    setSubmitting(true);
    try {
      const stationValue = isGhiab ? `${fromStation} ← ${toStation}` : station;
      await startTrip({
        userId: currentUser?.id || "",
        deviceId: "",
        driverName,
        vehicle,
        vehicleType,
        shift,
        station: stationValue,
        fromStation: isGhiab ? fromStation : undefined,
        toStation: isGhiab ? toStation : undefined,
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      showToast(`تم تسجيل ركوب ${driverName} على ${vehicle}`, "success");
      setVehicle(""); setShift(""); setStation("");
      setFromStation(""); setToStation("");
      if (!isDriver) setDriverName("");
      setVehicleType("");
    } finally {
      setSubmitting(false);
    }
  };

  const handleHandoff = async () => {
    if (!handoffTrip || !handoffDriver_) return;
    if (handoffDriver_ === handoffTrip.driverName) { showToast("السائق الجديد هو نفس السائق الحالي", "error"); return; }
    const driverAlreadyActive = activeTrips.find((t) => t.driverName === handoffDriver_ && t.id !== handoffTrip.id);
    if (driverAlreadyActive) { showToast(`السائق ${handoffDriver_} على ${driverAlreadyActive.vehicle} حالياً`, "error"); return; }
    setHandoffSubmitting(true);
    try {
      await handoffDriver(handoffTrip.id, handoffDriver_);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      showToast(`تم تسليم ${handoffTrip.vehicle} إلى ${handoffDriver_}`, "success");
      setHandoffTrip(null); setHandoffDriver_("");
    } finally {
      setHandoffSubmitting(false);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: colors.light.background }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <View style={styles.header}>
        <TouchableOpacity onPress={syncNow} style={styles.syncBtn} disabled={isSyncing}>
          {isSyncing
            ? <ActivityIndicator size="small" color="rgba(255,255,255,0.8)" />
            : <Feather name="refresh-cw" size={17} color="rgba(255,255,255,0.85)" />
          }
        </TouchableOpacity>
        <View style={styles.headerRight}>
          <Text style={styles.headerTitle}>تسجيل ركوب</Text>
          {isDriver && linkedDriverName ? (
            <View style={styles.driverBadge}>
              <Feather name="user" size={12} color={colors.light.success} />
              <Text style={styles.driverBadgeText}>{linkedDriverName}</Text>
            </View>
          ) : null}
        </View>
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 120 }]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {isLoading ? <ActivityIndicator color={colors.light.primary} style={{ marginTop: 40 }} /> : (
          <>
            <View style={styles.card}>
              <Text style={styles.sectionTitle}>نوع المركبة</Text>
              <View style={styles.typeGrid}>
                {VEHICLE_TYPES.map((vt) => (
                  <TouchableOpacity
                    key={vt.value}
                    style={[styles.typeBtn, vehicleType === vt.value && styles.typeBtnActive]}
                    onPress={() => handleVehicleTypeSelect(vt.value)}
                    activeOpacity={0.7}
                  >
                    <Text style={[styles.typeBtnText, vehicleType === vt.value && styles.typeBtnTextActive]}>{vt.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {vehicleType ? (
              <View style={styles.card}>
                <CustomPicker label="رقم المركبة" value={vehicle} options={vehicleOptions} onSelect={setVehicle} placeholder="اختر رقم المركبة" />
                <CustomPicker label="الوردية" value={shift} options={SHIFTS} onSelect={setShift} placeholder="اختر الوردية" />

                {isGhiab ? (
                  <>
                    <View style={styles.ghiabHint}>
                      <Feather name="navigation" size={14} color={colors.light.primary} />
                      <Text style={styles.ghiabHintText}>اختر محطة المغادرة والوصول</Text>
                    </View>
                    <CustomPicker label="من محطة" value={fromStation} options={STATIONS} onSelect={setFromStation} placeholder="محطة المغادرة" />
                    <CustomPicker label="إلى محطة" value={toStation} options={STATIONS} onSelect={setToStation} placeholder="محطة الوصول" />
                  </>
                ) : (
                  <CustomPicker label="المحطة" value={station} options={STATIONS} onSelect={setStation} placeholder="اختر المحطة" />
                )}

                {isDriver ? (
                  <View style={styles.fixedDriverBox}>
                    <Feather name="user" size={15} color={colors.light.primary} />
                    <Text style={styles.fixedDriverText}>السائق: {linkedDriverName}</Text>
                  </View>
                ) : (
                  <CustomPicker
                    label="السائق"
                    value={driverName}
                    options={driverOptions}
                    onSelect={setDriverName}
                    placeholder={drivers.length === 0 ? "لا يوجد سائقون" : "اختر السائق"}
                  />
                )}

                <TouchableOpacity
                  style={[styles.submitBtn, submitting && styles.submitBtnDisabled]}
                  onPress={handleSubmit}
                  disabled={submitting}
                  activeOpacity={0.8}
                >
                  {submitting ? <ActivityIndicator color="#fff" size="small" /> : (
                    <>
                      <Feather name="log-in" size={18} color="#fff" />
                      <Text style={styles.submitBtnText}>تسجيل ركوب</Text>
                    </>
                  )}
                </TouchableOpacity>
              </View>
            ) : null}

            {displayedActiveTrips.length > 0 && (
              <View style={styles.card}>
                <Text style={styles.sectionTitle}>
                  {isAdmin
                    ? `الرحلات النشطة (${activeTrips.length})`
                    : `رحلاتي النشطة (${myActiveTrips.length})`}
                </Text>
                {displayedActiveTrips.map((t) => {
                  const editable = canEdit(t, isAdmin);
                  return (
                    <View key={t.id} style={styles.activeTrip}>
                      <View style={styles.activeTripBtns}>
                        {editable && (
                          <TouchableOpacity style={styles.editBtn} onPress={() => setEditingTrip(t)}>
                            <Feather name="edit-2" size={13} color={colors.light.primary} />
                          </TouchableOpacity>
                        )}
                        <TouchableOpacity
                          style={styles.handoffBtn}
                          onPress={() => { setHandoffTrip(t); setHandoffDriver_(""); }}
                        >
                          <Feather name="repeat" size={13} color={colors.light.warning} />
                          <Text style={styles.handoffBtnText}>تسليم</Text>
                        </TouchableOpacity>
                      </View>
                      <View style={styles.activeDot} />
                      <View style={styles.activeTripInfo}>
                        <Text style={styles.activeTripVehicle}>{t.vehicle}</Text>
                        <Text style={styles.activeTripDriver}>{t.driverName}</Text>
                        <Text style={styles.activeTripStation}>{t.station}</Text>
                      </View>
                    </View>
                  );
                })}
              </View>
            )}
          </>
        )}
      </ScrollView>

      <TripEditModal
        trip={editingTrip}
        visible={editingTrip !== null}
        driverOptions={driverOptions}
        onClose={() => setEditingTrip(null)}
        onSave={async (id, data) => {
          await editTrip(id, data);
          showToast("تم تعديل الرحلة", "success");
          setEditingTrip(null);
        }}
      />

      <Modal visible={handoffTrip !== null} transparent animationType="fade" onRequestClose={() => setHandoffTrip(null)}>
        <Pressable style={styles.handoffOverlay} onPress={() => setHandoffTrip(null)}>
          <View style={styles.handoffModal} onStartShouldSetResponder={() => true}>
            <View style={styles.handoffHeader}>
              <Feather name="repeat" size={22} color={colors.light.warning} />
              <Text style={styles.handoffTitle}>تسليم وتسلم خارج الموقع</Text>
            </View>
            {handoffTrip && (
              <View style={styles.handoffInfo}>
                <Text style={styles.handoffVehicle}>{handoffTrip.vehicle}</Text>
                <Text style={styles.handoffCurrentDriver}>
                  السائق الحالي: <Text style={{ fontWeight: "700" as const }}>{handoffTrip.driverName}</Text>
                </Text>
              </View>
            )}
            <Text style={styles.handoffLabel}>السائق الجديد</Text>
            <CustomPicker
              label=""
              value={handoffDriver_}
              options={driverOptions.filter((d) => d.value !== handoffTrip?.driverName)}
              onSelect={setHandoffDriver_}
              placeholder="اختر السائق الجديد"
            />
            <View style={styles.handoffActions}>
              <TouchableOpacity style={styles.handoffCancelBtn} onPress={() => setHandoffTrip(null)}>
                <Text style={styles.handoffCancelText}>إلغاء</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.handoffConfirmBtn, (!handoffDriver_ || handoffSubmitting) && { opacity: 0.5 }]}
                onPress={handleHandoff}
                disabled={!handoffDriver_ || handoffSubmitting}
              >
                {handoffSubmitting ? <ActivityIndicator color="#fff" size="small" /> : (
                  <>
                    <Feather name="check" size={16} color="#fff" />
                    <Text style={styles.handoffConfirmText}>تأكيد التسليم</Text>
                  </>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </Pressable>
      </Modal>

      <Toast message={toast.message} type={toast.type} visible={toast.visible} onHide={hideToast} />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  header: {
    backgroundColor: colors.light.headerBg,
    paddingHorizontal: 20, paddingBottom: 16, paddingTop: 12,
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
  },
  headerRight: { alignItems: "flex-end", flex: 1 },
  headerTitle: { fontSize: 22, fontWeight: "700" as const, color: "#fff" },
  driverBadge: {
    flexDirection: "row", alignItems: "center", gap: 4,
    backgroundColor: "rgba(255,255,255,0.2)", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, marginTop: 4,
  },
  driverBadgeText: { fontSize: 13, color: "#fff", fontWeight: "600" as const },
  syncBtn: { padding: 6 },
  scroll: { flex: 1 },
  content: { padding: 16, gap: 12 },
  card: {
    backgroundColor: colors.light.card, borderRadius: colors.radius, padding: 16,
    shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 2,
  },
  sectionTitle: { fontSize: 16, fontWeight: "700" as const, color: colors.light.foreground, textAlign: "right", marginBottom: 12 },
  typeGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10, justifyContent: "flex-end" },
  typeBtn: {
    paddingHorizontal: 20, paddingVertical: 11, borderRadius: colors.radius,
    borderWidth: 2, borderColor: colors.light.border, backgroundColor: colors.light.background,
  },
  typeBtnActive: { borderColor: colors.light.primary, backgroundColor: colors.light.secondary },
  typeBtnText: { fontSize: 15, fontWeight: "600" as const, color: colors.light.mutedForeground },
  typeBtnTextActive: { color: colors.light.primary },
  ghiabHint: {
    flexDirection: "row", alignItems: "center", justifyContent: "flex-end",
    gap: 6, backgroundColor: colors.light.secondary, borderRadius: 8, padding: 10, marginBottom: 14,
  },
  ghiabHintText: { fontSize: 13, color: colors.light.primary, fontWeight: "600" as const },
  fixedDriverBox: {
    flexDirection: "row", alignItems: "center", justifyContent: "flex-end",
    gap: 8, backgroundColor: colors.light.secondary,
    borderRadius: 10, paddingHorizontal: 14, paddingVertical: 13,
    borderWidth: 1.5, borderColor: colors.light.primary + "40", marginTop: 4,
  },
  fixedDriverText: { fontSize: 15, fontWeight: "600" as const, color: colors.light.primary },
  submitBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    backgroundColor: colors.light.primary, borderRadius: colors.radius,
    paddingVertical: 14, marginTop: 4, gap: 8,
  },
  submitBtnDisabled: { opacity: 0.6 },
  submitBtnText: { color: "#fff", fontSize: 16, fontWeight: "700" as const },
  activeTrip: {
    flexDirection: "row", alignItems: "center", justifyContent: "flex-end",
    paddingVertical: 10,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.light.border,
    gap: 8,
  },
  activeDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.light.success },
  activeTripInfo: { alignItems: "flex-end", flex: 1 },
  activeTripVehicle: { fontSize: 15, fontWeight: "700" as const, color: colors.light.foreground },
  activeTripDriver: { fontSize: 13, color: colors.light.mutedForeground, marginTop: 1, writingDirection: "rtl" },
  activeTripStation: { fontSize: 12, color: colors.light.accent, marginTop: 1, writingDirection: "rtl" },
  activeTripBtns: { flexDirection: "row", gap: 6, alignItems: "center" },
  editBtn: {
    backgroundColor: colors.light.secondary, borderRadius: 8,
    padding: 7, borderWidth: 1, borderColor: colors.light.primary + "40",
  },
  handoffBtn: {
    flexDirection: "row", alignItems: "center", gap: 4,
    backgroundColor: "#FEF3C7", borderRadius: 8, padding: 7,
    borderWidth: 1, borderColor: colors.light.warning + "60",
  },
  handoffBtnText: { fontSize: 11, fontWeight: "600" as const, color: colors.light.warning },
  handoffOverlay: {
    flex: 1, backgroundColor: "rgba(0,0,0,0.5)",
    alignItems: "center", justifyContent: "center", padding: 20,
  },
  handoffModal: {
    backgroundColor: colors.light.card, borderRadius: 20, padding: 20, width: "100%",
  },
  handoffHeader: {
    flexDirection: "row", alignItems: "center", justifyContent: "flex-end",
    gap: 10, marginBottom: 16,
  },
  handoffTitle: { fontSize: 17, fontWeight: "700" as const, color: colors.light.foreground },
  handoffInfo: {
    backgroundColor: colors.light.secondary, borderRadius: 10,
    padding: 12, marginBottom: 16, alignItems: "flex-end",
  },
  handoffVehicle: { fontSize: 20, fontWeight: "800" as const, color: colors.light.primary },
  handoffCurrentDriver: { fontSize: 13, color: colors.light.mutedForeground, marginTop: 4, writingDirection: "rtl" },
  handoffLabel: { fontSize: 14, fontWeight: "600" as const, color: colors.light.foreground, textAlign: "right", marginBottom: 4 },
  handoffActions: { flexDirection: "row", gap: 12, marginTop: 8 },
  handoffCancelBtn: {
    flex: 1, paddingVertical: 13, borderRadius: 12,
    borderWidth: 1, borderColor: colors.light.border, alignItems: "center",
  },
  handoffCancelText: { fontSize: 14, fontWeight: "600" as const, color: colors.light.foreground },
  handoffConfirmBtn: {
    flex: 2, flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 8, paddingVertical: 13, borderRadius: 12,
    backgroundColor: colors.light.warning,
  },
  handoffConfirmText: { fontSize: 14, fontWeight: "700" as const, color: "#fff" },
});
