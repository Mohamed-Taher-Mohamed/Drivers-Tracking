import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { AppState, Platform } from "react-native";

export interface Driver {
  id: string;
  name: string;
  phone?: string;
}

export interface Trip {
  id: string;
  userId: string;
  deviceId: string;
  driverName: string;
  vehicle: string;
  vehicleType: string;
  shift: string;
  station: string;
  fromStation?: string;
  toStation?: string;
  startDatetime: string;
  endDatetime?: string;
  lastModified: string;
  synced: boolean;
}

export interface Conflict {
  id: string;
  tripAId: string;
  tripBId: string;
  reason: string;
  detectedAt: string;
  resolvedBy?: string;
  resolvedAt?: string;
  resolvedTripId?: string;
}

interface AppContextType {
  drivers: Driver[];
  trips: Trip[];
  conflicts: Conflict[];
  addDriver: (name: string, phone?: string) => Promise<{ ok: boolean; message: string }>;
  addDrivers: (entries: { name: string; phone?: string }[]) => Promise<{ added: number; skipped: number }>;
  editDriver: (id: string, name: string, phone?: string) => Promise<void>;
  deleteDriver: (id: string) => Promise<void>;
  startTrip: (data: Omit<Trip, "id" | "startDatetime" | "endDatetime" | "lastModified" | "synced">) => Promise<void>;
  endTrip: (tripId: string) => Promise<void>;
  editTrip: (tripId: string, data: Partial<Trip>) => Promise<boolean>;
  handoffDriver: (tripId: string, newDriverName: string) => Promise<boolean>;
  activeTrips: Trip[];
  myActiveTrips: Trip[];
  isLoading: boolean;
  isSyncing: boolean;
  lastSyncAt: string | null;
  syncNow: () => Promise<void>;
  resolveConflict: (conflictId: string, resolvedTripId: string, resolvedBy: string) => Promise<void>;
  canEdit: (trip: Trip, isAdmin: boolean) => boolean;
  liveConflictsCount: number;
  currentUserId: string;
}

const AppContext = createContext<AppContextType | null>(null);

const DRIVERS_KEY = "@dt_drivers_v3";
const TRIPS_KEY = "@dt_trips_v2";
const CONFLICTS_KEY = "@dt_conflicts_v2";
const SYNC_AT_KEY = "@dt_sync_at";

function getApiBase(): string {
  if (Platform.OS === "web") return "/api";
  const domain = process.env.EXPO_PUBLIC_DOMAIN;
  if (domain) return `https://${domain}/api`;
  return "http://localhost:80/api";
}

export function AppProvider({ children, userId, deviceId, linkedDriverName }: { children: React.ReactNode; userId: string; deviceId: string; linkedDriverName?: string }) {
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [trips, setTrips] = useState<Trip[]>([]);
  const [conflicts, setConflicts] = useState<Conflict[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncAt, setLastSyncAt] = useState<string | null>(null);

  const stateRef = useRef({ drivers, trips, conflicts, isSyncing });
  useEffect(() => { stateRef.current = { drivers, trips, conflicts, isSyncing }; }, [drivers, trips, conflicts, isSyncing]);

  useEffect(() => { loadData(); }, []);

  useEffect(() => {
    const sub = AppState.addEventListener("change", (state) => {
      if (state === "active") triggerSync();
    });
    return () => sub.remove();
  }, []);

  const triggerSync = () => {
    setTimeout(() => syncNow(), 300);
  };

  const loadData = async () => {
    try {
      const [driversJson, tripsJson, conflictsJson, syncAt] = await Promise.all([
        AsyncStorage.getItem(DRIVERS_KEY),
        AsyncStorage.getItem(TRIPS_KEY),
        AsyncStorage.getItem(CONFLICTS_KEY),
        AsyncStorage.getItem(SYNC_AT_KEY),
      ]);
      if (driversJson) setDrivers(JSON.parse(driversJson));
      if (tripsJson) setTrips(JSON.parse(tripsJson));
      if (conflictsJson) setConflicts(JSON.parse(conflictsJson));
      if (syncAt) setLastSyncAt(syncAt);
    } catch { } finally {
      setIsLoading(false);
      triggerSync();
    }
  };

  const saveDrivers = async (updated: Driver[]) => {
    setDrivers(updated);
    await AsyncStorage.setItem(DRIVERS_KEY, JSON.stringify(updated));
  };

  const saveTrips = async (updated: Trip[]) => {
    setTrips(updated);
    await AsyncStorage.setItem(TRIPS_KEY, JSON.stringify(updated));
  };

  const saveConflicts = async (updated: Conflict[]) => {
    setConflicts(updated);
    await AsyncStorage.setItem(CONFLICTS_KEY, JSON.stringify(updated));
  };

  const syncNow = useCallback(async () => {
    if (stateRef.current.isSyncing) return;
    setIsSyncing(true);
    try {
      const { trips: currentTrips, conflicts: currentConflicts } = stateRef.current;
      const base = getApiBase();
      const unsynced = currentTrips.filter((t) => !t.synced);
      if (unsynced.length > 0) {
        await fetch(`${base}/sync/push`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ trips: unsynced }),
        });
      }
      const pullRes = await fetch(`${base}/sync/pull`);
      if (!pullRes.ok) return;
      const { trips: serverTrips, conflicts: serverConflicts } = await pullRes.json() as { trips: Trip[]; conflicts: Conflict[] };
      const localById: Record<string, Trip> = {};
      for (const t of currentTrips) localById[t.id] = t;
      for (const st of serverTrips) {
        const existing = localById[st.id];
        if (!existing || st.lastModified > existing.lastModified) {
          localById[st.id] = { ...st, synced: true };
        } else {
          localById[st.id] = { ...existing, synced: true };
        }
      }
      await saveTrips(Object.values(localById));
      if (serverConflicts.length > 0) {
        const existingIds = new Set(currentConflicts.map((c) => c.id));
        const newOnes = serverConflicts.filter((c) => !existingIds.has(c.id));
        if (newOnes.length > 0) await saveConflicts([...currentConflicts, ...newOnes]);
      }
      const now = new Date().toISOString();
      setLastSyncAt(now);
      await AsyncStorage.setItem(SYNC_AT_KEY, now);
    } catch { } finally {
      setIsSyncing(false);
    }
  }, []);

  const addDriver = useCallback(async (name: string, phone?: string): Promise<{ ok: boolean; message: string }> => {
    const trimmed = name.trim();
    if (!trimmed) return { ok: false, message: "يرجى إدخال اسم السائق" };
    const exists = drivers.some((d) => d.name.trim().toLowerCase() === trimmed.toLowerCase());
    if (exists) return { ok: false, message: "السائق موجود بالفعل" };
    const newDriver: Driver = {
      id: Date.now().toString(36) + Math.random().toString(36).substr(2, 6),
      name: trimmed,
      phone: phone?.trim() || undefined,
    };
    await saveDrivers([...drivers, newDriver]);
    return { ok: true, message: "تم الإضافة" };
  }, [drivers]);

  const addDrivers = useCallback(async (entries: { name: string; phone?: string }[]): Promise<{ added: number; skipped: number }> => {
    const existing = new Set(drivers.map((d) => d.name.trim().toLowerCase()));
    const toAdd: Driver[] = [];
    let skipped = 0;
    for (const entry of entries) {
      const trimmed = entry.name.trim();
      if (!trimmed) continue;
      if (existing.has(trimmed.toLowerCase())) { skipped++; continue; }
      toAdd.push({
        id: Date.now().toString(36) + Math.random().toString(36).substr(2, 6),
        name: trimmed,
        phone: entry.phone?.trim() || undefined,
      });
      existing.add(trimmed.toLowerCase());
    }
    await saveDrivers([...drivers, ...toAdd]);
    return { added: toAdd.length, skipped };
  }, [drivers]);

  const editDriver = useCallback(async (id: string, name: string, phone?: string) => {
    await saveDrivers(drivers.map((d) => d.id === id ? { ...d, name: name.trim(), phone: phone?.trim() || undefined } : d));
  }, [drivers]);

  const deleteDriver = useCallback(async (id: string) => {
    await saveDrivers(drivers.filter((d) => d.id !== id));
  }, [drivers]);

  const startTrip = useCallback(async (data: Omit<Trip, "id" | "startDatetime" | "endDatetime" | "lastModified" | "synced">) => {
    const now = new Date().toISOString();
    const newTrip: Trip = {
      ...data,
      id: Date.now().toString(36) + Math.random().toString(36).substr(2, 8),
      startDatetime: now,
      lastModified: now,
      synced: false,
    };
    await saveTrips([...trips, newTrip]);
    triggerSync();
  }, [trips]);

  const endTrip = useCallback(async (tripId: string) => {
    const now = new Date().toISOString();
    await saveTrips(trips.map((t) => t.id === tripId ? { ...t, endDatetime: now, lastModified: now, synced: false } : t));
    triggerSync();
  }, [trips]);

  const canEdit = useCallback((trip: Trip, isAdmin: boolean): boolean => {
    if (isAdmin) return true;
    if (trip.userId !== userId) return false;
    return Date.now() - new Date(trip.startDatetime).getTime() < 10 * 60 * 1000;
  }, [userId]);

  const editTrip = useCallback(async (tripId: string, data: Partial<Trip>): Promise<boolean> => {
    const now = new Date().toISOString();
    await saveTrips(trips.map((t) => t.id === tripId ? { ...t, ...data, lastModified: now, synced: false } : t));
    triggerSync();
    return true;
  }, [trips]);

  const handoffDriver = useCallback(async (tripId: string, newDriverName: string): Promise<boolean> => {
    const now = new Date().toISOString();
    await saveTrips(trips.map((t) =>
      t.id === tripId ? { ...t, driverName: newDriverName, lastModified: now, synced: false } : t
    ));
    triggerSync();
    return true;
  }, [trips]);

  const resolveConflict = useCallback(async (conflictId: string, resolvedTripId: string, resolvedBy: string) => {
    try {
      const base = getApiBase();
      await fetch(`${base}/sync/resolve`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conflictId, resolvedTripId, resolvedBy }),
      });
    } catch { }
    const conflict = conflicts.find((c) => c.id === conflictId);
    if (conflict) {
      const losingId = conflict.tripAId === resolvedTripId ? conflict.tripBId : conflict.tripAId;
      await saveTrips(trips.filter((t) => t.id !== losingId));
    }
    await saveConflicts(conflicts.map((c) => c.id === conflictId ? { ...c, resolvedBy, resolvedAt: new Date().toISOString(), resolvedTripId } : c));
  }, [conflicts, trips]);

  const liveConflictsCount = useMemo(() => {
    const active = trips.filter((t) => !t.endDatetime);
    const driverCount: Record<string, number> = {};
    const vehicleCount: Record<string, number> = {};
    for (const t of active) {
      driverCount[t.driverName] = (driverCount[t.driverName] || 0) + 1;
      vehicleCount[t.vehicle] = (vehicleCount[t.vehicle] || 0) + 1;
    }
    let count = 0;
    for (const c of Object.values(driverCount)) if (c > 1) count++;
    for (const c of Object.values(vehicleCount)) if (c > 1) count++;
    return count;
  }, [trips]);

  const allActiveTrips = useMemo(() => trips.filter((t) => !t.endDatetime), [trips]);
  const myActiveTrips = useMemo(() => allActiveTrips.filter((t) =>
    t.userId === userId || (linkedDriverName && t.driverName === linkedDriverName)
  ), [allActiveTrips, userId, linkedDriverName]);

  return (
    <AppContext.Provider value={{
      drivers, trips, conflicts,
      addDriver, addDrivers, editDriver, deleteDriver,
      startTrip, endTrip, editTrip, handoffDriver,
      activeTrips: allActiveTrips,
      myActiveTrips,
      isLoading, isSyncing, lastSyncAt, syncNow,
      resolveConflict, canEdit, liveConflictsCount,
      currentUserId: userId,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
