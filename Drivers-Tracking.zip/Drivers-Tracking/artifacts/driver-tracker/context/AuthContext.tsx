import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";

export interface AppUser {
  id: string;
  username: string;
  password: string;
  role: "admin" | "user" | "driver";
  linkedDriverName?: string;
  createdAt: string;
}

interface AuthContextType {
  currentUser: AppUser | null;
  users: AppUser[];
  isLoading: boolean;
  deviceId: string;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  addUser: (username: string, password: string, role?: "admin" | "user" | "driver", linkedDriverName?: string) => Promise<{ ok: boolean; message: string }>;
  deleteUser: (id: string) => Promise<void>;
  changePassword: (id: string, newPassword: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

const USERS_KEY = "@dt_users_v3";
const SESSION_KEY = "@dt_session_v2";
const DEVICE_KEY = "@dt_device_id";

const ADMIN_SEED: AppUser = {
  id: "admin-seed",
  username: "admin",
  password: "admin",
  role: "admin",
  createdAt: new Date(0).toISOString(),
};

function genId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 8);
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [currentUser, setCurrentUser] = useState<AppUser | null>(null);
  const [users, setUsers] = useState<AppUser[]>([ADMIN_SEED]);
  const [isLoading, setIsLoading] = useState(true);
  const deviceIdRef = useRef<string>("");

  useEffect(() => { init(); }, []);

  const init = async () => {
    try {
      let did = await AsyncStorage.getItem(DEVICE_KEY);
      if (!did) { did = genId(); await AsyncStorage.setItem(DEVICE_KEY, did); }
      deviceIdRef.current = did;

      const usersJson = await AsyncStorage.getItem(USERS_KEY);
      let loadedUsers: AppUser[] = usersJson ? JSON.parse(usersJson) : [];
      const hasAdmin = loadedUsers.some((u) => u.username === "admin");
      if (!hasAdmin) loadedUsers = [ADMIN_SEED, ...loadedUsers];
      setUsers(loadedUsers);

      const sessionJson = await AsyncStorage.getItem(SESSION_KEY);
      if (sessionJson) {
        const session: { userId: string } = JSON.parse(sessionJson);
        const user = loadedUsers.find((u) => u.id === session.userId);
        if (user) setCurrentUser(user);
      }
    } catch {
    } finally {
      setIsLoading(false);
    }
  };

  const saveUsers = async (updated: AppUser[]) => {
    setUsers(updated);
    await AsyncStorage.setItem(USERS_KEY, JSON.stringify(updated));
  };

  const login = useCallback(async (username: string, password: string): Promise<boolean> => {
    const trimU = username.trim().toLowerCase();
    const user = users.find((u) => u.username.toLowerCase() === trimU && u.password === password);
    if (!user) return false;
    setCurrentUser(user);
    await AsyncStorage.setItem(SESSION_KEY, JSON.stringify({ userId: user.id }));
    return true;
  }, [users]);

  const logout = useCallback(async () => {
    setCurrentUser(null);
    await AsyncStorage.removeItem(SESSION_KEY);
  }, []);

  const addUser = useCallback(async (
    username: string,
    password: string,
    role: "admin" | "user" | "driver" = "user",
    linkedDriverName?: string,
  ): Promise<{ ok: boolean; message: string }> => {
    const trimU = username.trim();
    if (!trimU) return { ok: false, message: "اسم المستخدم مطلوب" };
    if (!password) return { ok: false, message: "كلمة المرور مطلوبة" };
    const exists = users.some((u) => u.username.toLowerCase() === trimU.toLowerCase());
    if (exists) return { ok: false, message: "اسم المستخدم موجود بالفعل" };
    const newUser: AppUser = {
      id: genId(), username: trimU, password, role,
      linkedDriverName: linkedDriverName?.trim() || undefined,
      createdAt: new Date().toISOString(),
    };
    await saveUsers([...users, newUser]);
    return { ok: true, message: "تم الإضافة" };
  }, [users]);

  const deleteUser = useCallback(async (id: string) => {
    if (id === "admin-seed") return;
    await saveUsers(users.filter((u) => u.id !== id));
  }, [users]);

  const changePassword = useCallback(async (id: string, newPassword: string) => {
    const updated = users.map((u) => u.id === id ? { ...u, password: newPassword } : u);
    await saveUsers(updated);
    if (currentUser?.id === id) setCurrentUser((u) => u ? { ...u, password: newPassword } : u);
  }, [users, currentUser]);

  return (
    <AuthContext.Provider value={{
      currentUser, users, isLoading, deviceId: deviceIdRef.current,
      login, logout, addUser, deleteUser, changePassword,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
