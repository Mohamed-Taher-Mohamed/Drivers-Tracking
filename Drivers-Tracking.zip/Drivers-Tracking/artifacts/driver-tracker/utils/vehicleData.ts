export const VEHICLE_TYPES = [
  { label: "خلاطة", value: "خلاطة" },
  { label: "مضخة", value: "مضخة" },
  { label: "بيك أب", value: "بيك أب" },
  { label: "ميني باص", value: "ميني باص" },
];

export const SHIFTS = [
  { label: "صباحية", value: "صباحية" },
  { label: "مسائية", value: "مسائية" },
  { label: "الذهاب إلى محطة", value: "الذهاب إلى محطة" },
];

export const STATIONS = [
  { label: "التجمع", value: "التجمع" },
  { label: "الهرم", value: "الهرم" },
  { label: "العاصمة", value: "العاصمة" },
  { label: "ERG", value: "ERG" },
  { label: "مستقبل مصر", value: "مستقبل مصر" },
  { label: "الرحاب", value: "الرحاب" },
  { label: "بورسعيد", value: "بورسعيد" },
  { label: "دمياط", value: "دمياط" },
  { label: "العلمين", value: "العلمين" },
  { label: "South.Med", value: "South.Med" },
  { label: "Cali.Cost", value: "Cali.Cost" },
  { label: "زايد", value: "زايد" },
  { label: "أخرى", value: "أخرى" },
];

function pad(n: number, prefix: string, width: number): string {
  return prefix + String(n).padStart(width, "0");
}

export function getVehicleOptions(type: string): { label: string; value: string }[] {
  switch (type) {
    case "خلاطة":
      return Array.from({ length: 84 }, (_, i) => {
        const v = `T${i + 1}`;
        return { label: v, value: v };
      });
    case "مضخة":
      return Array.from({ length: 20 }, (_, i) => {
        const v = pad(i + 1, "P", 2);
        return { label: v, value: v };
      });
    case "بيك أب":
      return Array.from({ length: 20 }, (_, i) => {
        const v = `PK-${String(i + 1).padStart(2, "0")}`;
        return { label: v, value: v };
      });
    case "ميني باص":
      return Array.from({ length: 20 }, (_, i) => {
        const v = pad(i + 1, "B", 2);
        return { label: v, value: v };
      });
    default:
      return [];
  }
}

export function formatDatetime(iso: string): string {
  if (!iso) return "-";
  const d = new Date(iso);
  const date = d.toLocaleDateString("ar-EG", { day: "2-digit", month: "2-digit", year: "numeric" });
  const time = d.toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" });
  return `${date} ${time}`;
}

export function tripStationLabel(trip: { shift: string; station: string; fromStation?: string; toStation?: string }): string {
  if (trip.shift === "الذهاب إلى محطة" && trip.fromStation && trip.toStation) {
    return `${trip.fromStation} ← ${trip.toStation}`;
  }
  return trip.station;
}
