const colors = {
  light: {
    text: "#0A1628",
    tint: "#0077B6",

    background: "#F0F4F8",
    foreground: "#0A1628",

    card: "#FFFFFF",
    cardForeground: "#0A1628",

    primary: "#0077B6",
    primaryForeground: "#FFFFFF",

    secondary: "#E8F4FD",
    secondaryForeground: "#0A1628",

    muted: "#EDF2F7",
    mutedForeground: "#64748B",

    accent: "#00B4D8",
    accentForeground: "#FFFFFF",

    destructive: "#E53E3E",
    destructiveForeground: "#FFFFFF",

    success: "#38A169",
    successForeground: "#FFFFFF",

    warning: "#D97706",
    warningForeground: "#FFFFFF",

    border: "#CBD5E0",
    input: "#E2E8F0",

    tabBar: "#FFFFFF",
    headerBg: "#0077B6",
    headerText: "#FFFFFF",
  },
  radius: 12,
};

export default colors;
