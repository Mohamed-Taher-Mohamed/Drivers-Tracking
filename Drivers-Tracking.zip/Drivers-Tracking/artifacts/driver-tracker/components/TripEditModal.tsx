import { Feather } from "@expo/vector-icons";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { CustomPicker } from "@/components/CustomPicker";
import colors from "@/constants/colors";
import { Trip } from "@/context/AppContext";
import { SHIFTS, STATIONS, VEHICLE_TYPES, getVehicleOptions } from "@/utils/vehicleData";

interface TripEditModalProps {
  trip: Trip | null;
  visible: boolean;
  driverOptions: { label: string; value: string }[];
  onClose: () => void;
  onSave: (tripId: string, data: Partial<Trip>) => Promise<void>;
}

export function TripEditModal({ trip, visible, driverOptions, onClose, onSave }: TripEditModalProps) {
  const insets = useSafeAreaInsets();
  const [driverName, setDriverName] = useState("");
  const [vehicle, setVehicle] = useState("");
  const [vehicleType, setVehicleType] = useState("");
  const [shift, setShift] = useState("");
  const [station, setStation] = useState("");
  const [fromStation, setFromStation] = useState("");
  const [toStation, setToStation] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (trip) {
      setDriverName(trip.driverName);
      setVehicle(trip.vehicle);
      setVehicleType(trip.vehicleType);
      setShift(trip.shift);
      setStation(trip.station);
      setFromStation(trip.fromStation || "");
      setToStation(trip.toStation || "");
    }
  }, [trip]);

  const vehicleOptions = vehicleType ? getVehicleOptions(vehicleType) : [];
  const isGhiab = shift === "الذهاب إلى محطة";

  const handleSave = async () => {
    if (!trip) return;
    setSaving(true);
    try {
      const stationValue = isGhiab ? `${fromStation} ← ${toStation}` : station;
      await onSave(trip.id, {
        driverName,
        vehicle,
        vehicleType,
        shift,
        station: stationValue,
        fromStation: isGhiab ? fromStation : undefined,
        toStation: isGhiab ? toStation : undefined,
      });
      onClose();
    } finally {
      setSaving(false);
    }
  };

  if (!trip) return null;

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={[styles.modal, { paddingBottom: insets.bottom + 16 }]}>
          <View style={styles.handle} />
          <View style={styles.header}>
            <TouchableOpacity onPress={onClose} style={styles.closeBtn}>
              <Feather name="x" size={22} color={colors.light.foreground} />
            </TouchableOpacity>
            <Text style={styles.title}>تعديل الرحلة</Text>
          </View>
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
            <CustomPicker label="السائق" value={driverName} options={driverOptions} onSelect={setDriverName} />
            <Text style={styles.sectionLabel}>نوع المركبة</Text>
            <View style={styles.typeGrid}>
              {VEHICLE_TYPES.map((vt) => (
                <TouchableOpacity
                  key={vt.value}
                  style={[styles.typeBtn, vehicleType === vt.value && styles.typeBtnActive]}
                  onPress={() => { setVehicleType(vt.value); setVehicle(""); }}
                  activeOpacity={0.7}
                >
                  <Text style={[styles.typeBtnText, vehicleType === vt.value && styles.typeBtnTextActive]}>
                    {vt.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            {vehicleType && (
              <CustomPicker label="رقم المركبة" value={vehicle} options={vehicleOptions} onSelect={setVehicle} />
            )}
            <CustomPicker label="الوردية" value={shift} options={SHIFTS} onSelect={setShift} />
            {isGhiab ? (
              <>
                <CustomPicker label="من محطة" value={fromStation} options={STATIONS} onSelect={setFromStation} placeholder="اختر محطة المغادرة" />
                <CustomPicker label="إلى محطة" value={toStation} options={STATIONS} onSelect={setToStation} placeholder="اختر محطة الوصول" />
              </>
            ) : (
              <CustomPicker label="المحطة" value={station} options={STATIONS} onSelect={setStation} />
            )}
            <TouchableOpacity
              style={[styles.saveBtn, saving && { opacity: 0.6 }]}
              onPress={handleSave}
              disabled={saving}
              activeOpacity={0.8}
            >
              {saving ? <ActivityIndicator color="#fff" size="small" /> : (
                <>
                  <Feather name="save" size={16} color="#fff" />
                  <Text style={styles.saveBtnText}>حفظ التعديلات</Text>
                </>
              )}
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" },
  modal: {
    backgroundColor: colors.light.card,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: "90%",
  },
  handle: {
    width: 40,
    height: 4,
    backgroundColor: colors.light.border,
    borderRadius: 2,
    alignSelf: "center",
    marginTop: 10,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.light.border,
    gap: 8,
  },
  title: { flex: 1, fontSize: 17, fontWeight: "700" as const, color: colors.light.foreground, textAlign: "right" },
  closeBtn: { padding: 4 },
  content: { padding: 20, gap: 0 },
  sectionLabel: { fontSize: 14, fontWeight: "600" as const, color: colors.light.foreground, textAlign: "right", marginBottom: 10 },
  typeGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8, justifyContent: "flex-end", marginBottom: 16 },
  typeBtn: {
    paddingHorizontal: 16,
    paddingVertical: 9,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: colors.light.border,
    backgroundColor: colors.light.background,
  },
  typeBtnActive: { borderColor: colors.light.primary, backgroundColor: colors.light.secondary },
  typeBtnText: { fontSize: 14, fontWeight: "600" as const, color: colors.light.mutedForeground },
  typeBtnTextActive: { color: colors.light.primary },
  saveBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    backgroundColor: colors.light.primary,
    borderRadius: colors.radius,
    paddingVertical: 14,
    marginTop: 8,
  },
  saveBtnText: { color: "#fff", fontSize: 15, fontWeight: "700" as const },
});
