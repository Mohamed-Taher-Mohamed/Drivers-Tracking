import { Feather } from "@expo/vector-icons";
import React, { useState } from "react";
import {
  FlatList,
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import colors from "@/constants/colors";

interface Option {
  label: string;
  value: string;
}

interface CustomPickerProps {
  label: string;
  value: string;
  options: Option[];
  onSelect: (value: string) => void;
  placeholder?: string;
}

export function CustomPicker({ label, value, options, onSelect, placeholder }: CustomPickerProps) {
  const [visible, setVisible] = useState(false);
  const insets = useSafeAreaInsets();
  const selected = options.find((o) => o.value === value);

  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}</Text>
      <TouchableOpacity style={styles.selector} onPress={() => setVisible(true)} activeOpacity={0.7}>
        <View style={styles.selectorInner}>
          <Feather name="chevron-down" size={18} color={colors.light.mutedForeground} />
          <Text style={[styles.selectorText, !selected && styles.placeholder]}>
            {selected ? selected.label : (placeholder || "اختر...")}
          </Text>
        </View>
      </TouchableOpacity>
      <Modal visible={visible} transparent animationType="slide" onRequestClose={() => setVisible(false)}>
        <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={() => setVisible(false)}>
          <View
            style={[styles.modal, { paddingBottom: insets.bottom + 16 }]}
            onStartShouldSetResponder={() => true}
          >
            <View style={styles.handle} />
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => setVisible(false)} style={styles.closeBtn}>
                <Feather name="x" size={20} color={colors.light.foreground} />
              </TouchableOpacity>
              <Text style={styles.modalTitle}>{label}</Text>
            </View>
            <FlatList
              data={options}
              keyExtractor={(item) => item.value}
              showsVerticalScrollIndicator={false}
              renderItem={({ item }) => {
                const isSelected = item.value === value;
                return (
                  <TouchableOpacity
                    style={[styles.option, isSelected && styles.optionSelected]}
                    onPress={() => { onSelect(item.value); setVisible(false); }}
                    activeOpacity={0.7}
                  >
                    <View style={styles.optionInner}>
                      {isSelected && (
                        <Feather name="check-circle" size={16} color={colors.light.primary} style={styles.checkIcon} />
                      )}
                      <Text style={[styles.optionText, isSelected && styles.optionTextSelected]}>
                        {item.label}
                      </Text>
                    </View>
                  </TouchableOpacity>
                );
              }}
            />
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginBottom: 16 },
  label: {
    fontSize: 14,
    fontWeight: "600" as const,
    color: colors.light.foreground,
    marginBottom: 8,
    textAlign: "right",
  },
  selector: {
    backgroundColor: colors.light.card,
    borderWidth: 1.5,
    borderColor: colors.light.border,
    borderRadius: colors.radius,
    paddingHorizontal: 14,
    paddingVertical: 13,
  },
  selectorInner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  selectorText: {
    flex: 1,
    fontSize: 15,
    color: colors.light.foreground,
    textAlign: "right",
    writingDirection: "rtl",
  },
  placeholder: { color: colors.light.mutedForeground },
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.45)",
    justifyContent: "flex-end",
  },
  modal: {
    backgroundColor: colors.light.card,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: "72%",
    paddingTop: 0,
  },
  handle: {
    width: 40,
    height: 4,
    backgroundColor: colors.light.border,
    borderRadius: 2,
    alignSelf: "center",
    marginTop: 10,
    marginBottom: 4,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.light.border,
    gap: 8,
  },
  modalTitle: {
    flex: 1,
    fontSize: 17,
    fontWeight: "700" as const,
    color: colors.light.foreground,
    textAlign: "right",
  },
  closeBtn: { padding: 4 },
  option: {
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.light.border,
  },
  optionSelected: { backgroundColor: colors.light.secondary },
  optionInner: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
    gap: 10,
  },
  checkIcon: { flexShrink: 0 },
  optionText: {
    fontSize: 16,
    color: colors.light.foreground,
    textAlign: "right",
    flexShrink: 1,
  },
  optionTextSelected: { color: colors.light.primary, fontWeight: "700" as const },
});
