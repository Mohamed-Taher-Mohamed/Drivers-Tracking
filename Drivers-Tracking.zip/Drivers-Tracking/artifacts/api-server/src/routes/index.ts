import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import syncRouter from "./sync.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use(syncRouter);

export default router;
