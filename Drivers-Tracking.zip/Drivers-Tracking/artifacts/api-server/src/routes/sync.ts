import { Router } from "express";
import { store } from "../lib/store.js";

const router = Router();

router.post("/auth/login", (req, res) => {
  const { username, password } = req.body as { username?: string; password?: string };
  if (!username || !password) {
    res.status(400).json({ error: "username and password required" });
    return;
  }
  const user = store.findUser(username);
  if (!user || user.password !== password) {
    res.status(401).json({ error: "invalid credentials" });
    return;
  }
  res.json({ id: user.id, username: user.username, role: user.role });
});

router.get("/users", (req, res) => {
  const users = store.getUsers().map(({ password: _, ...u }) => u);
  res.json(users);
});

router.post("/users", (req, res) => {
  const { username, password, role } = req.body as { username?: string; password?: string; role?: string };
  if (!username || !password) {
    res.status(400).json({ error: "username and password required" });
    return;
  }
  const exists = store.findUser(username);
  if (exists) {
    res.status(409).json({ error: "user already exists" });
    return;
  }
  const user = store.addUser({
    username,
    password,
    role: role === "admin" ? "admin" : "user",
    createdAt: new Date().toISOString(),
  });
  res.json({ id: user.id, username: user.username, role: user.role });
});

router.delete("/users/:id", (req, res) => {
  const { id } = req.params;
  if (id === "admin-seed") {
    res.status(403).json({ error: "cannot delete admin" });
    return;
  }
  store.deleteUser(id!);
  res.json({ ok: true });
});

router.post("/sync/push", (req, res) => {
  const { trips } = req.body as { trips?: unknown[] };
  if (!Array.isArray(trips)) {
    res.status(400).json({ error: "trips must be an array" });
    return;
  }
  const newConflicts = store.pushTrips(trips as any);
  res.json({ ok: true, newConflicts: newConflicts.length });
});

router.get("/sync/pull", (req, res) => {
  const trips = store.getTrips();
  const conflicts = store.getConflicts();
  res.json({ trips, conflicts });
});

router.post("/sync/resolve", (req, res) => {
  const { conflictId, resolvedTripId, resolvedBy } = req.body as {
    conflictId?: string;
    resolvedTripId?: string;
    resolvedBy?: string;
  };
  if (!conflictId || !resolvedTripId || !resolvedBy) {
    res.status(400).json({ error: "conflictId, resolvedTripId, resolvedBy required" });
    return;
  }
  const ok = store.resolveConflict(conflictId, resolvedTripId, resolvedBy);
  if (!ok) {
    res.status(404).json({ error: "conflict not found" });
    return;
  }
  res.json({ ok: true });
});

export default router;
