import fs from "node:fs";
import path from "node:path";

export interface StoreUser {
  id: string;
  username: string;
  password: string;
  role: "admin" | "user";
  createdAt: string;
}

export interface StoreTrip {
  id: string;
  userId: string;
  deviceId: string;
  driverName: string;
  vehicle: string;
  vehicleType: string;
  shift: string;
  station: string;
  fromStation?: string;
  toStation?: string;
  startDatetime: string;
  endDatetime?: string;
  lastModified: string;
}

export interface StoreConflict {
  id: string;
  tripAId: string;
  tripBId: string;
  reason: string;
  detectedAt: string;
  resolvedBy?: string;
  resolvedAt?: string;
  resolvedTripId?: string;
}

interface Store {
  users: StoreUser[];
  trips: StoreTrip[];
  conflicts: StoreConflict[];
}

const STORE_PATH = path.join("/tmp", "driver_tracker_store.json");

const DEFAULT_STORE: Store = {
  users: [
    {
      id: "admin-seed",
      username: "admin",
      password: "admin",
      role: "admin",
      createdAt: new Date(0).toISOString(),
    },
  ],
  trips: [],
  conflicts: [],
};

function readStore(): Store {
  try {
    if (!fs.existsSync(STORE_PATH)) return { ...DEFAULT_STORE };
    const raw = fs.readFileSync(STORE_PATH, "utf-8");
    const parsed: Store = JSON.parse(raw);
    if (!parsed.users.find((u) => u.username === "admin")) {
      parsed.users.unshift(DEFAULT_STORE.users[0]!);
    }
    return parsed;
  } catch {
    return { ...DEFAULT_STORE };
  }
}

function writeStore(store: Store): void {
  fs.writeFileSync(STORE_PATH, JSON.stringify(store, null, 2), "utf-8");
}

function genId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 8);
}

function hasTimeOverlap(a: StoreTrip, b: StoreTrip): boolean {
  const aStart = new Date(a.startDatetime).getTime();
  const aEnd = a.endDatetime ? new Date(a.endDatetime).getTime() : Date.now() + 86400000;
  const bStart = new Date(b.startDatetime).getTime();
  const bEnd = b.endDatetime ? new Date(b.endDatetime).getTime() : Date.now() + 86400000;
  return aStart < bEnd && aEnd > bStart;
}

export const store = {
  getUsers(): StoreUser[] {
    return readStore().users;
  },

  findUser(username: string): StoreUser | undefined {
    return readStore().users.find((u) => u.username.toLowerCase() === username.toLowerCase());
  },

  addUser(data: Omit<StoreUser, "id">): StoreUser {
    const s = readStore();
    const user: StoreUser = { id: genId(), ...data };
    s.users.push(user);
    writeStore(s);
    return user;
  },

  deleteUser(id: string): void {
    const s = readStore();
    s.users = s.users.filter((u) => u.id !== id);
    writeStore(s);
  },

  getTrips(): StoreTrip[] {
    return readStore().trips;
  },

  pushTrips(incoming: StoreTrip[]): StoreConflict[] {
    const s = readStore();
    const newConflicts: StoreConflict[] = [];

    for (const trip of incoming) {
      const idx = s.trips.findIndex((t) => t.id === trip.id);
      if (idx >= 0) {
        if (trip.lastModified > s.trips[idx]!.lastModified) {
          s.trips[idx] = trip;
        }
      } else {
        s.trips.push(trip);
        for (const existing of s.trips) {
          if (existing.id === trip.id) continue;
          if (existing.userId === trip.userId) continue;
          if (!hasTimeOverlap(trip, existing)) continue;

          let reason = "";
          if (trip.vehicle === existing.vehicle) {
            reason = `تعارض مركبة: ${trip.vehicle}`;
          } else if (trip.driverName === existing.driverName) {
            reason = `تعارض سائق: ${trip.driverName}`;
          }
          if (!reason) continue;

          const alreadyExists = s.conflicts.find(
            (c) =>
              (c.tripAId === trip.id && c.tripBId === existing.id) ||
              (c.tripAId === existing.id && c.tripBId === trip.id)
          );
          if (!alreadyExists) {
            newConflicts.push({
              id: genId(),
              tripAId: trip.id,
              tripBId: existing.id,
              reason,
              detectedAt: new Date().toISOString(),
            });
          }
        }
      }
    }

    s.conflicts.push(...newConflicts);
    writeStore(s);
    return newConflicts;
  },

  getConflicts(): StoreConflict[] {
    return readStore().conflicts;
  },

  resolveConflict(conflictId: string, resolvedTripId: string, resolvedBy: string): boolean {
    const s = readStore();
    const conflict = s.conflicts.find((c) => c.id === conflictId);
    if (!conflict) return false;
    conflict.resolvedBy = resolvedBy;
    conflict.resolvedAt = new Date().toISOString();
    conflict.resolvedTripId = resolvedTripId;
    const losingTripId = conflict.tripAId === resolvedTripId ? conflict.tripBId : conflict.tripAId;
    s.trips = s.trips.filter((t) => t.id !== losingTripId);
    writeStore(s);
    return true;
  },
};
