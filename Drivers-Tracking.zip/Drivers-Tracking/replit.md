# نظام تتبع السائقين

تطبيق موبايل متعدد المستخدمين يعمل بدون إنترنت لتسجيل وتتبع السائقين على المركبات — مع مزامنة تلقائية عند توفر النت وحل تعارضات البيانات.

## Run & Operate

- `pnpm --filter @workspace/driver-tracker run dev` — run the Expo app
- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080, proxied at /api)
- `pnpm run typecheck` — full typecheck across all packages
- Default login: admin / admin

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Mobile: Expo + Expo Router (file-based routing)
- Storage: AsyncStorage (offline-first, no backend needed)
- UI: React Native + @expo/vector-icons
- State: React Context + AsyncStorage
- API: Express on port 8080, JSON file store at /tmp/driver_tracker_store.json

## Where things live

- `artifacts/driver-tracker/` — Expo mobile app
- `artifacts/driver-tracker/context/AuthContext.tsx` — user auth (login, users CRUD)
- `artifacts/driver-tracker/context/AppContext.tsx` — trips, drivers, sync, conflicts
- `artifacts/driver-tracker/utils/vehicleData.ts` — vehicle lists, stations, shifts
- `artifacts/driver-tracker/components/CustomPicker.tsx` — reusable RTL modal picker
- `artifacts/driver-tracker/components/TripEditModal.tsx` — trip edit modal
- `artifacts/driver-tracker/app/(tabs)/` — 5 screens: index, end-trip, search, drivers, conflicts
- `artifacts/driver-tracker/app/login.tsx` — login screen
- `artifacts/api-server/src/lib/store.ts` — JSON file storage for server
- `artifacts/api-server/src/routes/sync.ts` — sync + auth API routes

## Architecture decisions

- Fully offline — AsyncStorage as primary store, API as sync target
- Arabic RTL UI with `I18nManager.allowRTL(true)`
- Vehicle type selected via buttons (not dropdown), then shows vehicle-specific dropdown
- Custom modal picker for better RTL/Expo Go compatibility
- Duplicate driver/vehicle validation on trip start
- "الذهاب إلى محطة" shift triggers from/to station pickers
- Auth stored in AsyncStorage (offline-first); admin/admin pre-seeded
- Sync on app foreground + manual refresh button; conflict detection on server
- Trip edit: 10-min window for users, unlimited for admin

## Product

- **تسجيل ركوب**: اختيار نوع المركبة، الرقم، الوردية، المحطة، السائق
- **الذهاب إلى محطة**: وردية خاصة بمحطتين (من/إلى)
- **تسجيل نزول**: عرض الرحلات النشطة مع تأكيد
- **البحث**: فلترة حسب السائق / المركبة / التاريخ / الوردية
- **الإدارة**: سائقون + مستخدمون (أدمن فقط) + تسجيل خروج
- **أخطاء التسجيل**: حل تعارضات البيانات (أدمن فقط)
- **تعديل الرحلة**: في أول 10 دقائق للمستخدم، بدون قيد للأدمن
- **مزامنة**: تلقائية عند فتح التطبيق، يدوية بزر الريفريش

## Gotchas

- Do NOT install `uuid` — use `Date.now().toString(36) + Math.random()` for IDs
- Expo workflow only needs restart when changing dependencies or hitting Metro errors
- Web preview uses `Platform.OS === "web"` guard for top padding (67px)
- API server store path: `/tmp/driver_tracker_store.json` (resets on server restart)
